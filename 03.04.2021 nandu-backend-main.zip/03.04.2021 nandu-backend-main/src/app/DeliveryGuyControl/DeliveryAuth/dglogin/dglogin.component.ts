import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dglogin',
  templateUrl: './dglogin.component.html',
  styleUrls: ['./dglogin.component.css']
})
export class DgloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
