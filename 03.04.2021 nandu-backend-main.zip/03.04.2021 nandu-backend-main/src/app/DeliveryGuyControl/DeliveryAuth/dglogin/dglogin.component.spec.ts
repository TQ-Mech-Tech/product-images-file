import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DgloginComponent } from './dglogin.component';

describe('DgloginComponent', () => {
  let component: DgloginComponent;
  let fixture: ComponentFixture<DgloginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DgloginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DgloginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
