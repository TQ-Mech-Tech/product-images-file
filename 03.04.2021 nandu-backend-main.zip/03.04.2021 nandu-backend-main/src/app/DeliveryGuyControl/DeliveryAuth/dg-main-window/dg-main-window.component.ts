import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { AddMillComponent } from './add-mill/add-mill.component';
import { AddPaymentComponent } from './add-payment/add-payment.component';
interface Product {
  id: string;
  productName: string;
  grindingType: string;
  weight: string;
  price: string;
  servicesCharge: string;
}

interface Profile {
  cust_id:string;
  customerName:string;
  customerAddress:string;
  sector:string;
  plotNo:string;
  tal:string;
  city:string;
}


interface OrderData {
  id: string;
  date: string;
  product: Product[];
  pickUpDate: string;
  dropingDate: string;
  totalWeight: string;
  deliveryCharge: string;
  totalAmount: string;
  orderTrack:string;
  orderStatus:string;
  custInfo:Profile[];
}

@Component({
  selector: 'app-dg-main-window',
  templateUrl: './dg-main-window.component.html',
  styleUrls: ['./dg-main-window.component.css']
})
export class DgMainWindowComponent implements OnInit {

  constructor( public addDialogForPayment: MatDialog , public addDailogForMill: MatDialog) { }
 
  displayedColumns2: string[] = ['PickUpDate', 'DroppingDate', 'TotalWeight', 'DeliveryCharge'];
  displayedColumns: string[] = ['ProductName','GrindingType','Weight','Price','ServiceCharge'];
  displayColumnsTable2:string[] =['PickupDate'];
  orderDetails:OrderData[]=[{
    id: '1',
  date: "23/Jan/2021",
  product:[{id:'12',productName:"lokvan wheat",grindingType:"hard grinding",weight:"11 kg",price:"77",servicesCharge:"22"},
  {id:'13',productName:"wheat",grindingType:"lean grinding",weight:"15 kg",price:"105",servicesCharge:"30"},
  {id:'14',productName:"wheat",grindingType:"fine grinding",weight:"18 kg",price:"126",servicesCharge:"36"},
  {id:'13',productName:"wheat",grindingType:"leansd grinding",weight:"15 kg"/*suffix kg will be remove from db and UI takes it.*/ ,price:"105",servicesCharge:"30"}],
  pickUpDate:"27/jan/2021",
  dropingDate:"30/jan/2021",
  totalWeight:"11 kg",
  deliveryCharge:"20",
  totalAmount:"127",
  orderTrack:"20",
  orderStatus:"pending",
  custInfo:[{cust_id:'121',customerName:'sohame rajput',customerAddress:'Vidya gagan, kharghar, navi mumbai',
  sector:'23',plotNo:'32',tal:'panvel',city:'Mumbai'}]
},
{
  id: '2',
date: "4/Feb/2021",
product:[{id:'12',productName:"lokvan wheat",grindingType:"hard grinding",weight:"11 kg",price:"77",servicesCharge:"22"},
{id:'13',productName:"wheat",grindingType:"lean grinding",weight:"15 kg",price:"105",servicesCharge:"30"},
{id:'14',productName:"wheat",grindingType:"fine grinding",weight:"18 kg",price:"126",servicesCharge:"36"}],
pickUpDate:"4/Feb/2021",
dropingDate:"6/Feb/2021",
totalWeight:"11 kg",
deliveryCharge:"20",
totalAmount:"657",
orderTrack:"100",
orderStatus:"paid",
custInfo:[{cust_id:'151',customerName:'Aradhya rajput',customerAddress:'Vidya gagan, kharghar, navi mumbai',
  sector:'21',plotNo:'29',tal:'panvel',city:'Mumbai'}]
}]

// interface Profile {
//   cust_id:string;
//   customerName:string;
//   customerAddress:string;
//   sector:string;
//   plotNo:string;
//   tal:string;
//   city:string;
// }
  disabled = true;
  invert = false;
  count = 0;
  counting_values = this.orderDetails.length;
  datep = "12 jan 2021"
  step = 1;
  thumbLabel = false;
  totalMoney = "232";
  value = 50;
  vertical = false;
  disableReadOnlyValue = true;
  orderStatus = "Paid";

  openDialogAddPayment() {
    const dialogRef = this.addDialogForPayment.open(AddPaymentComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  openDialogAddMill() {
    const dialogRef = this.addDialogForPayment.open(AddMillComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }

  ngOnInit(): void {
  }
  getyourId(data:string){
    console.log('your id is ',data);
  }


}
