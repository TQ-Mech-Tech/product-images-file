import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';

@Component({
  selector: 'app-add-mill',
  templateUrl: './add-mill.component.html',
  styleUrls: ['./add-mill.component.css']
})
export class AddMillComponent implements OnInit {

  constructor(private _snackBar: MatSnackBar) {}
  durationInSeconds = 5;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  CheckFormCondition(form:NgForm){

    {
         this._snackBar.open("Data has been saved successfully . . .", 'Done', {
           duration: this.durationInSeconds * 1000,
           horizontalPosition: this.horizontalPosition,
           verticalPosition: this.verticalPosition,
         });

       }

     }

  addMillForm:FormGroup;

  ngOnInit(): void {
    this.addMillForm = new FormGroup({
      millName :new FormControl(null, {validators:[Validators.required]}),
      millOwnerName :new FormControl(null, { validators:[Validators.required]}),
      contactNumber :new FormControl(null, { validators:[Validators.required]}),
      sectorOrlocation :new FormControl(null, { validators:[Validators.required]}),
      city:new FormControl(null, { validators:[Validators.required]}),

    });

  }

}
