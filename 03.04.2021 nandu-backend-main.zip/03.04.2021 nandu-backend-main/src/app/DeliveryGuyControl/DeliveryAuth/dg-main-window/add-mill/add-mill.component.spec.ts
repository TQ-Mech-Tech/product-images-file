import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddMillComponent } from './add-mill.component';

describe('AddMillComponent', () => {
  let component: AddMillComponent;
  let fixture: ComponentFixture<AddMillComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddMillComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMillComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
