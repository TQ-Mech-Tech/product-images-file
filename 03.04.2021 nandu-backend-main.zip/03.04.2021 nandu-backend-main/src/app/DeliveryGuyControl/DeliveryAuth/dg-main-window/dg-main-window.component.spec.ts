import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DgMainWindowComponent } from './dg-main-window.component';

describe('DgMainWindowComponent', () => {
  let component: DgMainWindowComponent;
  let fixture: ComponentFixture<DgMainWindowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DgMainWindowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DgMainWindowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
