import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import {MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition} from '@angular/material/snack-bar';
interface ServiceProvider {
  value: string;
  viewMode:string;
}

@Component({
  selector: 'app-add-payment',
  templateUrl: './add-payment.component.html',
  styleUrls: ['./add-payment.component.css']
})
export class AddPaymentComponent implements OnInit {



  datepickerStyles = {'color':'blue','margin-top':'2px'}
  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6;
  }

  paymentType: ServiceProvider[] = [
    {value: 'Phonepe-0', viewMode: 'Phonepe'},
    {value: 'Google Pay-1', viewMode:'Google Pay'},
    {value: 'Amazon Pay-2', viewMode:'Amazon Pay'},
    {value: 'Cash-3', viewMode:'Cash'},
    {value: 'Others-4', viewMode:'Others'}
  ];
  public addPayment :FormGroup

  constructor(private _snackBar: MatSnackBar) {}
  durationInSeconds = 5;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';



  CheckFormCondition(form:NgForm){

 {
      this._snackBar.open("Data has been saved successfully . . .", 'Done', {
        duration: this.durationInSeconds * 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
      });

    }

  }

  ngOnInit(): void {
    this.addPayment = new FormGroup({
      firstName: new FormControl( null , { validators:[Validators.required]}),
      middleName: new FormControl( null , { validators:[Validators.required]}),
      lastName: new FormControl( null , { validators:[Validators.required]}),
      pickDate: new FormControl( null , { validators:[Validators.required]}),
      Time: new FormControl( null , { validators:[Validators.required]}),
      orderId: new FormControl( null , { validators:[Validators.required]}),
      paymentMode: new FormControl( null , { validators:[Validators.required]}),
      totalAmount: new FormControl( null , { validators:[Validators.required]})
    });
  }

}
