import { Component, OnInit, AfterViewInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css', './whatwedo.component.css','aboutUs.component.css']
})
export class WelcomeComponent implements OnInit {

  constructor(){

  }


  ngOnInit():void{
    const typedTextSpan = document.querySelector(".typed-text");
    const cursorSpan = document.querySelector(".cursor");

    const textArray = ["On Your Demand, ","On Your Door."];
    const typingDelay = 100;
    const erasingDelay = 100;
    const newTextDelay = 2000; // Delay between current and next text
    let textArrayIndex = 0;
    let charIndex = 0;

    function type() {
    if (charIndex < textArray[textArrayIndex].length) {
      if(!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
      typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
      charIndex++;
      setTimeout(type, typingDelay);
    } 
    else {
      cursorSpan.classList.remove("typing");
      setTimeout(erase, newTextDelay);
    }
    }

    function erase() {
    if (charIndex > 0) {
      if(!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
      typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex-1);
      charIndex--;
      setTimeout(erase, erasingDelay);
    } 
    else {
      cursorSpan.classList.remove("typing");
      textArrayIndex++;
      if(textArrayIndex>=textArray.length) textArrayIndex=0;
      setTimeout(type, typingDelay + 1100);
    }
    }

    console.log("my welcome component calling");

        (()=>{
          if(textArray.length) setTimeout(type, newTextDelay + 250);
        })();

    // if (document.readyState !== 'loading'){
    //   document.addEventListener('DOMContentLoaded', function() {
    //     if(textArray.length) setTimeout(type, newTextDelay + 250);
    //   });
    // }
    // else{
    //   document.addEventListener('DOMContentLoaded', function() {
    //     if(textArray.length) setTimeout(type, newTextDelay + 250);
    //   });
    // } 
    // document.addEventListener("", function() { // On DOM Load initiate the effect
    //   if(textArray.length) setTimeout(type, newTextDelay + 250);
    // });
    }
    
     
  }

  //  init() {
  //       console.log("Do it !");

  //       const typedTextSpan = document.querySelector(".typed-text");
  //       const cursorSpan = document.querySelector(".cursor");

  //       const textArray = ["hard", "fun", "a journey", "LIFE"];
  //       const typingDelay = 200;
  //       const erasingDelay = 100;
  //       const newTextDelay = 2000; // Delay between current and next text
  //       let textArrayIndex = 0;
  //       let charIndex = 0;

  //       function type() {
  //       if (charIndex < textArray[textArrayIndex].length) {
  //         if(!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
  //         typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
  //         charIndex++;
  //         setTimeout(type, typingDelay);
  //       } 
  //       else {
  //         cursorSpan.classList.remove("typing");
  //         setTimeout(erase, newTextDelay);
  //       }
  //       }

  //       function erase() {
  //       if (charIndex > 0) {
  //         if(!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
  //         typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex-1);
  //         charIndex--;
  //         setTimeout(erase, erasingDelay);
  //       } 
  //       else {
  //         cursorSpan.classList.remove("typing");
  //         textArrayIndex++;
  //         if(textArrayIndex>=textArray.length) textArrayIndex=0;
  //         setTimeout(type, typingDelay + 1100);
  //       }
  //       }

  //       console.log("my welcome component calling");
  //       // document.addEventListener("", function() { // On DOM Load initiate the effect
  //       //   if(textArray.length) setTimeout(type, newTextDelay + 250);
  //       // });
  //       }


  

//     const typedTextSpan = document.querySelector(".typed-text");
// const cursorSpan = document.querySelector(".cursor");

// const textArray = ["hard", "fun", "a journey", "LIFE"];
// const typingDelay = 200;
// const erasingDelay = 100;
// const newTextDelay = 2000; // Delay between current and next text
// let textArrayIndex = 0;
// let charIndex = 0;

// function type() {
//   if (charIndex < textArray[textArrayIndex].length) {
//     if(!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
//     typedTextSpan.textContent += textArray[textArrayIndex].charAt(charIndex);
//     charIndex++;
//     setTimeout(type, typingDelay);
//   } 
//   else {
//     cursorSpan.classList.remove("typing");
//   	setTimeout(erase, newTextDelay);
//   }
// }

// function erase() {
// 	if (charIndex > 0) {
//     if(!cursorSpan.classList.contains("typing")) cursorSpan.classList.add("typing");
//     typedTextSpan.textContent = textArray[textArrayIndex].substring(0, charIndex-1);
//     charIndex--;
//     setTimeout(erase, erasingDelay);
//   } 
//   else {
//     cursorSpan.classList.remove("typing");
//     textArrayIndex++;
//     if(textArrayIndex>=textArray.length) textArrayIndex=0;
//     setTimeout(type, typingDelay + 1100);
//   }
// }
 
// console.log("my welcome component calling");
// document.addEventListener("DOMContentLoaded", function() { // On DOM Load initiate the effect
//   if(textArray.length) setTimeout(type, newTextDelay + 250);
// });
 




// typedTextSpan = document.querySelector(".typed-text");
// cursorSpan = document.querySelector(".cursor");

// textArray = ["On Your Demand, ","On Your Door."];
// typingDelay = 100;
// erasingDelay = 100;
// newTextDelay = 2000; // Delay between current and next text
// textArrayIndex = 0;
// charIndex = 0;

//    ngOnInit():void
//  {
 
//    function type() {
//      if (this.charIndex < this.textArray[this.textArrayIndex].length) {
//        if(!this.cursorSpan.classList.contains("typing")) this.cursorSpan.classList.add("typing");
//        this.typedTextSpan.textContent += this.textArray[this.textArrayIndex].charAt(this.charIndex);
//        this.charIndex++;
//        setTimeout(type, this.typingDelay);
//      } 
//      else {
//        this.cursorSpan.classList.remove("typing");
//        setTimeout(erase, this.newTextDelay);
//      }
//    }
   
//    function erase() {
//      if (this.charIndex > 0) {
//        if(!this.cursorSpan.classList.contains("typing")) this.cursorSpan.classList.add("typing");
//        this.typedTextSpan.textContent = this.textArray[this.textArrayIndex].substring(0, this.charIndex-1);
//        this.charIndex--;
//        setTimeout(erase, this.erasingDelay);
//      } 
//      else {
//        this.cursorSpan.classList.remove("typing");
//        this.textArrayIndex++;
//        if(this.textArrayIndex>=this.textArray.length) this.textArrayIndex=0;
//        setTimeout(type, this.typingDelay + 1100);
//      }
//    }
   
  
//  }

//  ngAfterViewInit():void{
//    document.addEventListener("DOMContentLoaded", function() { // On DOM Load initiate the effect
//      if(this.textArray.length) setTimeout(this.type, this.newTextDelay + 250);
//    });
//  }