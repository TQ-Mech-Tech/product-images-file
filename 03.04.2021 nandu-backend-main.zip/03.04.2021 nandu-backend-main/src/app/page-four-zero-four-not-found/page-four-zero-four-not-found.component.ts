import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-four-zero-four-not-found',
  templateUrl: './page-four-zero-four-not-found.component.html',
  styleUrls: ['./page-four-zero-four-not-found.component.css']
})
export class PageFourZeroFourNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
