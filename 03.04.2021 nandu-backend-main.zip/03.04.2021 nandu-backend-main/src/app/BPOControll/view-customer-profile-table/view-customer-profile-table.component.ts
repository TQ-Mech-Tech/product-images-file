import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

import {MatDialog} from '@angular/material/dialog';
import { UpdateCustomerProfileComponent } from './update-customer-profile/update-customer-profile.component';
import { CustomerViewProfileService } from './view-customer-profile.service';

interface CustomerProfile{
  id:string;
  login_id:string;
  firstname:string;
  middlename:string;
  lastname:string;
  homeaddress:string;
  sector:string;
  plotno:string;
  city:string;
  tal:string;
  dist:string;
  state:string;
  pincode:string;
  mob:string;
}

const ELEMENT_DATA: CustomerProfile[] = [
 { id:"121",
  login_id:"12",
  firstname:'sohame',
  middlename:'manohar',
  lastname:'sisodiya',
  homeaddress:'tulsi gagan',
  sector:'21',
  plotno:'25',
  city:'kharghar',
  tal:'panvel',
  dist:'jalgaon',
  state:'raidad',
  pincode:'102030',
  mob:'9393049389'},
  { id:"123",
  login_id:"14",
  firstname:'Aisha',
  middlename:'manohar',
  lastname:'sisodiya',
  homeaddress:'tulsi gagan',
  sector:'21',
  plotno:'25',
  city:'kharghar',
  tal:'panvel',
  dist:'jalgaon',
  state:'raidad',
  pincode:'102030',
  mob:'9393049389'}
];

@Component({
  selector: 'app-view-customer-profile-table',
  templateUrl: './view-customer-profile-table.component.html',
  styleUrls: ['./view-customer-profile-table.component.css']
})
export class ViewCustomerProfileTableComponent implements OnInit {

  constructor(public dialog: MatDialog,private custUpdateProfileService:CustomerViewProfileService) { }


  displayedColumns: string[] = ['id','login_id','firstname','middlename','lastname','homeaddress','sector','plotno','city',
'tal','dist','state','pincode','mob','actions'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  // custID(custIDvalue){
  //   console.log(custIDvalue.value);
  // }

  openDialog(inputValue) {
    console.log(inputValue.value);
    this.custUpdateProfileService.putCustUpdateId(inputValue.value);
    const dialogRef = this.dialog.open(UpdateCustomerProfileComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }



  ngOnInit(): void {
  }

}
