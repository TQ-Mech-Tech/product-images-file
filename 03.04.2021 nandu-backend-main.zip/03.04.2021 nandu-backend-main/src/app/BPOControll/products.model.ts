export interface Products{
  id:string;
  productname:string;
  grindingtype:string;
  weight:string;
  price:string;
  servicecharge:string;
  surcharge:string;
  sgst:string;
  cgst:string;
  totalamount:string;
  imageurl:string;
  productstatus:string;
  detail:string;
  bpoID:string;
}
