import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

interface PaymentInfo{
  firstName:string,
  middleName:string,
  lastName:string,
  paymentDate:string,
  paymentTime:string,
  orderId:string,
  paymentStatus:string,
  totalAmount:string,
  totalCash:string
}

const ELEMENT_DATA:PaymentInfo[]=[{
  firstName:'Nandu',
  middleName:'A',
  lastName:'Chopade',
  paymentDate:'15 Jan 2021',
  paymentTime:'12:38',
  orderId:'1234567',
  paymentStatus:'Done',
  totalAmount: 'Rs 90',
  totalCash:'-'

},
{
  firstName:'Rudresh',
  middleName:'M',
  lastName:'Sisode',
  paymentDate:'15 Jan 2021',
  paymentTime:'01:38',
  orderId:'1234568',
  paymentStatus:'Done',
  totalAmount: 'Rs 120',
  totalCash:'-'
        }];

@Component({
  selector: 'app-payment-info',
  templateUrl: './payment-info.component.html',
  styleUrls: ['./payment-info.component.css']
})
export class PaymentInfoComponent implements OnInit {

  constructor() { }

  displayedColumns: string[] = ['firstName',	'middleName',	'lastName',	'paymentDate',	'paymentTime',	'orderId', 'paymentStatus','totalAmount','totalCash'];

  dataSource = new MatTableDataSource(ELEMENT_DATA);

   applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
     this.dataSource.filter = filterValue.trim().toLowerCase();
    }



  ngOnInit(): void {
  }

}
