import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-small-device-not-supported',
  templateUrl: './small-device-not-supported.component.html',
  styleUrls: ['./small-device-not-supported.component.css']
})
export class SmallDeviceNotSupportedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
