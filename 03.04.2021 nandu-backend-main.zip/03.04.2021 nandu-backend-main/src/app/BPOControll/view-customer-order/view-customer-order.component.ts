import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

import {MatDialog} from '@angular/material/dialog';
import { ViewCustomerOrderService } from './view-customer-order.service';
interface Order{
  id:string;
  customerprofileid:string;
  OrderPlaceDate:string;
  productid:string;
  PickupDate:string;
  DroppingDate:string;
  TotalWeight:string;
  DeliveryCharge:string;
  TotalAmount:string;
  OrderTrack:string;
  OrderStatus:string;
  Signal:string;
}


const ELEMENT_DATA: Order[] = [
  {
    id:"233",
    customerprofileid:"333",
    OrderPlaceDate:"23/jan/2021",
    productid:"221",
    PickupDate:"12/jan/2021",
    DroppingDate:"17/jan/2021",
    TotalWeight:"23 kg",
    DeliveryCharge:"23",
    TotalAmount:"122",
    OrderTrack:"20",
    OrderStatus:"pending",
    Signal:"Approved"
  },
  {
    id:"234",
    customerprofileid:"335",
    OrderPlaceDate:"23/jan/2021",
    productid:"221",
    PickupDate:"12/jan/2021",
    DroppingDate:"17/jan/2021",
    TotalWeight:"23 kg",
    DeliveryCharge:"23",
    TotalAmount:"122",
    OrderTrack:"20",
    OrderStatus:"pending",
    Signal:"cancle"
  },
  {
    id:"235",
    customerprofileid:"633",
    OrderPlaceDate:"23/jan/2021",
    productid:"221",//all product in array [] format
    PickupDate:"12/jan/2021",
    DroppingDate:"17/jan/2021",
    TotalWeight:"23 kg",
    DeliveryCharge:"23",
    TotalAmount:"122",
    OrderTrack:"20",
    OrderStatus:"pending",
    Signal:"Approved"
  }
]


@Component({
  selector: 'app-view-customer-order',
  templateUrl: './view-customer-order.component.html',
  styleUrls: ['./view-customer-order.component.css']
})
//
export class ViewCustomerOrderComponent implements OnInit {
  constructor(public dialog: MatDialog,private viewCustomerorderservice:ViewCustomerOrderService) { }
  expression=true;
  displayedColumns: string[] = ['id','customerprofileid','OrderPlaceDate','productid','PickupDate','DroppingDate','TotalWeight',
  'DeliveryCharge','TotalAmount','OrderTrack','OrderStatus','Signal','productDetails'];
  dataSource = new MatTableDataSource(ELEMENT_DATA);
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }


  opendComp(inputValue){

    if(this.expression){
      this.viewCustomerorderservice.putCustUpdateId(inputValue.value);
    }
    this.expression = !this.expression;


  }

  ngOnInit(): void {
  }

}
