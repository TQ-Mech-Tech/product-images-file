import { Component, OnInit } from '@angular/core';
import { ViewCustomerOrderService } from '../view-customer-order.service';
import {MatTableDataSource} from '@angular/material/table';

interface OrderedProductDetails{
  id:string;
  prodName:string;
  GrindingType:string;
  Weight:string;
  Price:string;
  ServiceCharge:string;
  TotalPrice:string;
  ImageUrl:string;
  Status:string;
  Details:string;

}

const ELEMENT_DATA: OrderedProductDetails[] = [ ];


@Component({
  selector: 'app-view-customer-order-product-details',
  templateUrl: './view-customer-order-product-details.component.html',
  styleUrls: ['./view-customer-order-product-details.component.css']
})
export class ViewCustomerOrderProductDetailsComponent implements OnInit {
  dataSource = new MatTableDataSource(ELEMENT_DATA);
                  // id:string;
                  // prodName:string;
                  // GrindingType:string;
                  // Weight:string;
                  // Price:string;
                  // ServiceCharge:string;
                  // TotalPrice:string;
                  // ImageUrl:string;
                  // Status:string;
                  // Details:string;
  displayedColumns: string[] = ['id','prodName','GrindingType','Weight','Price','ServiceCharge','TotalPrice','ImageUrl','Status',
'Details'];
id:string;
  constructor(private viewCustomerorderservice:ViewCustomerOrderService) {

   }

  ngOnInit(): void {
    this.id = this.viewCustomerorderservice.getCustUpdateId();
    console.log('your id is ',this.id);

  }

}
