
import {Component,OnInit} from '@angular/core';

interface Food{
  value: string;
  viewValue: string;
}

interface Profile{
  firstName:string;
  middleName:string;
  LastName:string;
  mobile:string;
}

@Component({
  selector: 'app-dg-responsible-for-area',
  templateUrl: './dg-responsible-for-area.component.html',
  styleUrls: ['./dg-responsible-for-area.component.css']
})

export class DGResponsibleForAreaComponent implements OnInit {



constructor(){

}
  ngOnInit(): void {
  }
  disableReadOnlyValue = true;

  // firstName:string;
  // middleName:string;
  // LastName:string;
  // mobile:string;

  customerInfo:Profile[]=[
    {firstName:'Rudresh',middleName:'Manohar',LastName:'Sisode',mobile:'7218502858'}
  ]

  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];
}
