import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

interface AccountableFor{
  id:string;
  loginId:string;
  profileId:string;
  firstName:string;
  middleName:string;
  lastName:string;
  mobileNo:string;
  state:string;
  city:string;
  sector:string;
  pinCode:string;

}

const ELEMENT_DATA:AccountableFor[]=[{
            id:'23',
            loginId:'02',
            profileId:'334',
            firstName:'atul',
            middleName:'digambar',
            lastName:'patil',
            mobileNo:'944949390',
            state:'maharastra',
            city:'kothrud',
            sector:'32,12,32',
            pinCode:'434334'
          },
        {id:'24',
          loginId:'03',
          profileId:'335',
          firstName:'Rahul',
          middleName:'digambar',
          lastName:'sonawane',
          mobileNo:'9865322356',
          state:'maharastra',
          city:'kothrud',
          sector:'32,12,32',
          pinCode:'434334'
        }];

@Component({
  selector: 'app-view-responsible',
  templateUrl: './view-responsible.component.html',
  styleUrls: ['./view-responsible.component.css']
})
export class ViewResponsibleComponent implements OnInit {

  constructor() { }
          // id:'23',
          // loginId:'02',
          // profileId:'334',
          // firstName:'atul',
          // middleName:'digambar',
          // lastName:'patil',
          // mobileNo:'944949390',
          // state:'maharastra',
          // city:'kothrud',
          // sector:'32,12,32',
          // pinCode:'434334'

    displayedColumns: string[] = ['id','loginId','profileId','firstName','middleName','lastName','mobileNo',
    'state','city','sector','pinCode'];

    dataSource = new MatTableDataSource(ELEMENT_DATA);

     applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
       this.dataSource.filter = filterValue.trim().toLowerCase();
      }

  ngOnInit(): void {
  }

}
