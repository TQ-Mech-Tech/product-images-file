import { Component, OnInit } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';

interface MillInfo{
  millName:string,
  ownerName:string,
  contactNumber:string,
  sectorOrNearLocation:string,
  city:string
}

const ELEMENT_DATA:MillInfo[]=[{

  millName:'Lakshi Mill',
  ownerName:'Suresh D chadhari',
  contactNumber:'9784838409',
  sectorOrNearLocation:'Three Monkey - 8',
  city:'Kharghar'

},
{
  millName:'Mauli Mill',
  ownerName:'Dinesh P Patil',
  contactNumber:'9784838408',
  sectorOrNearLocation:'Tulsi Gagan - 21',
  city:'Kharghar'

}];

@Component({
  selector: 'app-mill-info',
  templateUrl: './mill-info.component.html',
  styleUrls: ['./mill-info.component.css']
})
export class MillInfoComponent implements OnInit {

  constructor() { }

  displayedColumns: string[] = ['millName',	'ownerName', 'contactNumber',	'sectorOrNearLocation',	'city'];

  dataSource = new MatTableDataSource(ELEMENT_DATA);

   applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
     this.dataSource.filter = filterValue.trim().toLowerCase();
    }



  ngOnInit(): void {
  }

}
