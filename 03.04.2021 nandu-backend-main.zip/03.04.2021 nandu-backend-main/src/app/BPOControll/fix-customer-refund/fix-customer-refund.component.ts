import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

interface RefundData{
  id:string;
  custProfileId:string;
  Orderid:string;
  TotalAmount:string;
  RefundRequestedDate:string;
  RefundApprovedDate:string;
  //OrderStatus:string;// paid// pending//
  //RefundStatus:string;//approved or cancle
  //paymentid:string// this will come from razorpay

}


const ELEMENT_DATA:RefundData[]=[{
  id:"121",
  custProfileId:"0232",
  Orderid:"002",
  TotalAmount:"444",
  RefundRequestedDate:"32/jan/2021",
  RefundApprovedDate:"35/jan/2021"
}];

@Component({
  selector: 'app-fix-customer-refund',
  templateUrl: './fix-customer-refund.component.html',
  styleUrls: ['./fix-customer-refund.component.css']
})
export class FixCustomerRefundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
              // id:string;
              // custProfileId:string;
              // Orderid:string;
              // TotalAmount:string;
              // RefundRequestedDate:string;
              // RefundApprovedDate:string;
  displayedColumns: string[] = ['id','custProfileId','Orderid','TotalAmount','RefundRequestedDate','RefundApprovedDate','action-btn1','action-btn2'];

  dataSource = new MatTableDataSource(ELEMENT_DATA);

  approvedReq(inputValue){
    console.log(`request of id ${inputValue.value} is approved.`)
  }

  cancleReq(inputValue){
    console.log(`request of id ${inputValue.value} is cancle.`)
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    //this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
