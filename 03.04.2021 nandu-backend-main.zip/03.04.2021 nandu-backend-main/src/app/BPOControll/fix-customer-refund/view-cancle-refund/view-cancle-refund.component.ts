import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

interface RefundData{
  id:string;
  custProfileId:string;
  Orderid:string;
  TotalAmount:string;
  RefundRequestedDate:string;
  RefundApprovedDate:string;
  OrderStatus:string;// paid// pending//
  RefundStatus:string;//approved or cancle
  paymentid:string// this will come from razorpay

}

const ELEMENT_DATA:RefundData[]=[{
  id:"121",
  custProfileId:"0232",
  Orderid:"002",
  TotalAmount:"444",
  RefundRequestedDate:"32/jan/2021",
  RefundApprovedDate:"35/jan/2021",
  OrderStatus:"pending",
  RefundStatus:"Approved",
  paymentid:"48usdsdlk492-49sllsdkujalk&4339"
}];
//9 schema
@Component({
  selector: 'app-view-cancle-refund',
  templateUrl: './view-cancle-refund.component.html',
  styleUrls: ['./view-cancle-refund.component.css']
})
export class ViewCancleRefundComponent implements OnInit {

  constructor() { }
  displayedColumns: string[] = ['id','custProfileId','Orderid','TotalAmount',
  'RefundRequestedDate','RefundApprovedDate','OrderStatus','RefundStatus','paymentid'];

  dataSource = new MatTableDataSource(ELEMENT_DATA);
  ngOnInit(): void {
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

}
