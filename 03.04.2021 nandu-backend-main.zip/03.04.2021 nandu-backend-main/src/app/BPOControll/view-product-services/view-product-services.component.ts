import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-product-services',
  templateUrl: './view-product-services.component.html',
  styleUrls: ['./view-product-services.component.css']
})
export class ViewProductServicesComponent implements OnInit {
  product_value = 115;
  productKG = 5;
  constructor() { }

  ngOnInit() {

  }
  openDialog(){

  }
}
