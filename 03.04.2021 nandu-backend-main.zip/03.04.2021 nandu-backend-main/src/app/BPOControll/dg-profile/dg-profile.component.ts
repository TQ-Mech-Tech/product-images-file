import { Component, OnInit } from '@angular/core';
interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-dg-profile',
  templateUrl: './dg-profile.component.html',
  styleUrls: ['./dg-profile.component.css']
})
export class DGProfileComponent implements OnInit {

  constructor() { }
  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];

  ngOnInit(): void {

  }

  printk(){
    console.log("your button ok")
  }

  dgMob(searchReslt){
    console.log("your search result is ",searchReslt.value);
  }

}
