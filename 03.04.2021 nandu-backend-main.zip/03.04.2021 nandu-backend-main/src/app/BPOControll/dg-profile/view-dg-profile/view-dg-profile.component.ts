import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

interface DGProfile{
  id:string;
  firstName:string;
  middleName:string;
  lastName:string;
  homeAddress:string;
  state:string;
  dist:string;
  tal:string;
  city:string;
  pinNo:string;
  mobNo:string;
  alterMobNo:string;
  bankAcNo:string;
  bankBranch:string;
  bankIFSC:string;
}

const ELEMENT_DATA:DGProfile[]=[{
  id:'6',
  firstName:'atul',
  middleName:'digambar',
  lastName:'patil',
  homeAddress:'Aflatul',
  state:'Jamalpur',
  dist:'Rastur',
  tal:'raigad',
  city:'kharghar',
  pinNo:'23232',
  mobNo:'4949494949',
  alterMobNo:'9343939393',
  bankAcNo:'6899385493839458',
  bankBranch:'shirpur',
  bankIFSC:'IDFO0900'
},
{
  id:'7',
  firstName:'atul',
  middleName:'digambar',
  lastName:'patil',
  homeAddress:'Aflatul',
  state:'Jamalpur',
  dist:'Rastur',
  tal:'raigad',
  city:'kharghar',
  pinNo:'23232',
  mobNo:'4949494949',
  alterMobNo:'9343939393',
  bankAcNo:'6899385493839458',
  bankBranch:'shirpur',
  bankIFSC:'IDFO0900'
}
]

@Component({
  selector: 'app-view-dg-profile',
  templateUrl: './view-dg-profile.component.html',
  styleUrls: ['./view-dg-profile.component.css']
})
export class ViewDgProfileComponent implements OnInit {

  constructor() { }

  // firstName:'atul',
  // middleName:'digambar',
  // lastName:'patil',
  // homeAddress:'Aflatul',
  // state:'Jamalpur',
  // dist:'Rastur',
  // tal:'raigad',
  // city:'kharghar',
  // pinNo:'23232',
  // mobNo:'4949494949',
  // alterMobNo:'9343939393',
  // bankAcNo:'6899385493839458',
  // bankBranch:'shirpur',
  // bankIFSC:'IDFO0900'
  displayedColumns: string[] = ['id','firstName','middleName','lastName','homeAddress','state','dist','tal','city','pinNo','mobNo',
'alterMobNo','bankAcNo','bankBranch','bankIFSC'];

  dataSource = new MatTableDataSource(ELEMENT_DATA);

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  ngOnInit(): void {
  }

}
