import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DGSignUpComponent } from './dg-sign-up.component';

describe('DGSignUpComponent', () => {
  let component: DGSignUpComponent;
  let fixture: ComponentFixture<DGSignUpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DGSignUpComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DGSignUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
