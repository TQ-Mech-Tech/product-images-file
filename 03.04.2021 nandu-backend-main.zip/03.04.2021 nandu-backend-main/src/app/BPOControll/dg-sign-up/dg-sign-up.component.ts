/*
 {path:'/dg-sign-up',component:DGSignUpComponent},
  {path:'/dg-responsible-for-area',component:DGResponsibleForAreaComponent},
  {path:'/dg-profile',component:DGProfileComponent}
*/
import { Component, OnInit } from '@angular/core';



@Component({
  selector: 'app-dg-sign-up',
  templateUrl: './dg-sign-up.component.html',
  styleUrls: ['./dg-sign-up.component.css']
})
export class DGSignUpComponent implements OnInit {

  hide = true;
  constructor(){


  }


  ngOnInit() {


  }

}
