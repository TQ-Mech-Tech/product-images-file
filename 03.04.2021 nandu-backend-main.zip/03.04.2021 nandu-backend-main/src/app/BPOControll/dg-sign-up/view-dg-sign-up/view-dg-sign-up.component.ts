import { Component, OnInit } from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';

interface DGSIGNUP{
  id:string;
  username:string;
  email:string;
  mobile:string;
  pass:string;
}

const ELEMENT_DATA:DGSIGNUP[]=[{id:"3498",username:"ahudip",email:"ahud@gmail.com",mobile:"32454321",pass:"48kvp285AL;KFG"},
{id:"3498",username:"ahudip",email:"ahud@gmail.com",mobile:"32454321",pass:"48kvp285AL;KFG"}]

@Component({
  selector: 'app-view-dg-sign-up',
  templateUrl: './view-dg-sign-up.component.html',
  styleUrls: ['./view-dg-sign-up.component.css']
})
export class ViewDgSignUpComponent implements OnInit {

  constructor() { }

  // id:string;
  // username:string;
  // email:string;
  // mobile:string;
  // pass:string;
  displayedColumns: string[] = ['id','username','email','mobile','pass','EDIT','DELETE'];

    dataSource = new MatTableDataSource(ELEMENT_DATA);

     applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
       this.dataSource.filter = filterValue.trim().toLowerCase();
      }
      eidt(){
        console.log("doston edit")

      }
      deledl(){
        console.log("dorpon dlelte")
      }
  ngOnInit(): void {
  }

}
