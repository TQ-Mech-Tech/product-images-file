export interface GrindProducts{
  id:string;
  productname:string;
  grindingtype:string;
  weight:string;
  price:string;
  serviceCharge:string;
  totalAmount:string;
  BPOuserID:string;
}
