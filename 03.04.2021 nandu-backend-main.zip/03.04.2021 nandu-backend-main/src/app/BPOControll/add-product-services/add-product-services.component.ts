import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, FormGroupName, Validators } from '@angular/forms';
import { BPOcontrolService } from '../bpo-control.service';

// import {SmallDeviceNotSupportedComponent} from '../small-device-not-supported/small-device-not-supported.component';
const reg = /(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[-A-Z0-9+&@#\/%=~_|$?!:,.])*(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[A-Z0-9+&@#\/%=~_|$])/igm;
const re =  /^[a-z0-9\\-]/;
const  regexfordeciamal = '^[0-9]+(\.[0-9]{1,2})?$';
@Component({
  selector: 'app-add-product-services',
  templateUrl: './add-product-services.component.html',
  styleUrls: ['./add-product-services.component.css']
})
export class AddProductServicesComponent implements OnInit {

  addProductServiceForm:FormGroup;
  imageURL:string;
  productID:string;

  calculatedProductPriceAndDeliveryCharge:number;
  calcualtSurchage:number;
  totalGst:number;
  calculatedGrossAndSurcharge:number;
  claculatedGst:number;
  netAmount:number;

  constructor(private bpoService:BPOcontrolService) { }


  ngOnInit(): void {
    this.productID= "";
// this.errorComponent;
    this.addProductServiceForm = new FormGroup({
    productName : new FormControl(null,{validators:[Validators.required,Validators.pattern(re), Validators.minLength(4)]}),
    grindingType : new FormControl(null,{validators:[Validators.required,Validators.minLength(4)]}),
    weightOfProduct : new FormControl(null,{validators:[Validators.required,Validators.pattern(/^\d{1,3}kg/),Validators.minLength(2)]}),
    priceOfProduct : new FormControl(null,{validators:[Validators.required,Validators.pattern(/^[1-9]\d*(\.\d+)?$/),Validators.minLength(2)]}),
    serviceCharge : new FormControl(null,{validators:[Validators.required,Validators.pattern(/^[0-9]*$/)]}),
    totalAmount : new FormControl(null,{validators:[Validators.required,Validators.pattern(/^[1-9]\d*(\.\d+)?$/),Validators.minLength(2)]}),
    gitImageUrl : new FormControl(null,{validators:[Validators.required,Validators.pattern(reg)]}),
    productStatus : new FormControl(null,{validators:[Validators.required]}),
    detailsOfProduct : new FormControl(null,{validators:[Validators.required,Validators.minLength(4)]}),
    surCharge:  new FormControl(null,{validators:[Validators.required,Validators.pattern(regexfordeciamal),Validators.minLength(1)]}),
    sgst: new FormControl(null,{validators:[Validators.required,Validators.pattern(regexfordeciamal),Validators.minLength(1)]}),
    cgst: new FormControl(null,{validators:[Validators.required,Validators.pattern(regexfordeciamal),Validators.minLength(1)]}),
  });

  }

  getTotalAmountValue(){

    this.calculatedProductPriceAndDeliveryCharge =  +this.addProductServiceForm.value.priceOfProduct + +this.addProductServiceForm.value.serviceCharge;
    this.calcualtSurchage = this.calculatedProductPriceAndDeliveryCharge * +this.addProductServiceForm.value.surCharge / 100;
   // calcualtSurchage = calcualtSurchage.toFixed(2);
    this.totalGst =  +this.addProductServiceForm.value.sgst + +this.addProductServiceForm.value.cgst;
    this.calculatedGrossAndSurcharge = this.calculatedProductPriceAndDeliveryCharge +parseFloat( this.calcualtSurchage.toFixed(2));
    this.claculatedGst = this.calculatedGrossAndSurcharge * this.totalGst/100;
    this.netAmount = this.calculatedGrossAndSurcharge +parseFloat(this.claculatedGst.toFixed(2)) ;

    //  this.form.controls['dept'].setValue(selected.id);
    this.addProductServiceForm.controls['totalAmount'].setValue(this.netAmount.toFixed(2));

 }



// getTotalAmount(){
//          this.gst = this.sgst + this.cgst ;

//          this.price = this.price * 5 / 100;

//          this.totalPrice = this.price + this.serviceCharge + this.surcharge ;
//          console.log("your total price is " + this.totalPrice)
// }

  oncheckclick(){
    this.imageURL = this.addProductServiceForm.value.gitImagePath;



  }

  onSave(){
    if(this.addProductServiceForm.invalid){
      console.log("your form is not valid boss");
      return ;

    }

    this.bpoService.addProductInfo(this.productID,this.addProductServiceForm.value.productName,
      this.addProductServiceForm.value.grindingType, this.addProductServiceForm.value.weightOfProduct,
      this.addProductServiceForm.value.priceOfProduct, this.addProductServiceForm.value.serviceCharge,
      this.addProductServiceForm.value.totalAmount, this.addProductServiceForm.value.gitImagePath,
      this.addProductServiceForm.value.productStatus, this.addProductServiceForm.value.detailsOfProduct,
      this.addProductServiceForm.value.cgst, this.addProductServiceForm.value.surCharge,
      this.addProductServiceForm.value.sgst);
  }

}



//this.customerProfileForm.value.firstName,
    // this.customerProfileForm.value.middleName,
    /**productName :
    grindingType :
    weightOfProduct :
    priceOfProduct :
    serviceCharge :
    totalAmount :
    gitImagePath :
    productStatus :
    detailsOfProduct  */
