import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { first, map } from "rxjs/operators";
import { Router } from "@angular/router";

import {Products} from './products.model';
import { GrindProducts } from "./grinding-product";

@Injectable({ providedIn: "root" })

export class BPOcontrolService{

  constructor(private http: HttpClient, private router: Router) {    }

  addProductInfo(id:string,productname:string,grindingtype:string,weight:string,price:string,servicecharge:string,totalamount:string,
    imageurl:string,productstatus:string,detail:string,surcharge:string,sgst:string,cgst:string){
/**surcharge:string;
  sgst:string;
  cgst:string; */
      const productDataInfo : Products ={
        id:id,
        productname:productname,
        grindingtype:grindingtype,
        weight:weight,
        price:price,
        servicecharge:servicecharge,
        surcharge:surcharge,
        sgst:sgst,
        cgst:cgst,
        totalamount:totalamount,
        imageurl:imageurl,
        productstatus:productstatus,
        detail:detail,
        bpoID : null  }

        this.http.post<{message:string,data:string}>("http://localhost:3000/api/bpo-addproductservice/add-products",productDataInfo)
        .subscribe(responseData =>{
          console.log("your response from ",responseData.message)
        });
  }

  getProductInfo(){

  }
/** id:string;
  productname:string;
  grindingtype:string;
  weight:string;
  price:string;
  serviceCharge:string;
  totalAmount:string;
  BPOuserID:string; */

  addGrindingProduct(prodname:string,type:string,weight:string,price:string,serviceCharge:string,totalAmount:string){

    const grindProdInfo : GrindProducts ={
      id:"none",
      productname:prodname,
      grindingtype:type,
      weight:weight,
      price:price,
      serviceCharge:serviceCharge,
      totalAmount:totalAmount,
      BPOuserID:"none"
    }
    this.http.post<{message:string,data:any}>("http://localhost:3000/api/bpo-addproductservice/add-grinding-products",grindProdInfo)
    .subscribe(result =>{
      console.log("grindig data adding result ",result.message, result.data);

    });

  }
}
