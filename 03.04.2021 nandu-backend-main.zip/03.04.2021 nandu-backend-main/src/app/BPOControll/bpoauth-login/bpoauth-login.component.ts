import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-bpoauth-login',
  templateUrl: './bpoauth-login.component.html',
  styleUrls: ['./bpoauth-login.component.css']
})
export class BPOauthLoginComponent implements OnInit {

  bpoAuthLogin:FormGroup;

  constructor() { }
  ngOnInit(): void {
    // this.errorComponent;
    this.bpoAuthLogin = new FormGroup({
      email : new FormControl(null,{validators:[Validators.required,Validators.email]}),
      Password:new FormControl(null,{validators:[Validators.required,Validators.pattern('/^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/')]}),
    });
      }

      onSave(){
        if(this.bpoAuthLogin.invalid){
          console.log('your form is not valid');
          return;
        }
      }

      }
