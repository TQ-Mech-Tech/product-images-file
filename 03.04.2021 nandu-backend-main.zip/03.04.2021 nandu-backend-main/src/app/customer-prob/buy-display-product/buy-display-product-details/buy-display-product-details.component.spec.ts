import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyDisplayProductDetailsComponent } from './buy-display-product-details.component';

describe('BuyDisplayProductDetailsComponent', () => {
  let component: BuyDisplayProductDetailsComponent;
  let fixture: ComponentFixture<BuyDisplayProductDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyDisplayProductDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyDisplayProductDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
