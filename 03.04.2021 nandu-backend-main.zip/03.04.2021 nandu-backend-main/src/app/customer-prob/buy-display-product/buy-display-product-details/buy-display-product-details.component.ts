import { Component, OnInit } from '@angular/core';
import {MatDialog} from '@angular/material/dialog';
import { BPOProducts } from '../../bpo-products.models';
import { CustomersService } from '../../customers.service';
interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-buy-display-product-details',
  templateUrl: './buy-display-product-details.component.html',
  styleUrls: ['./buy-display-product-details.component.css']
})
export class BuyDisplayProductDetailsComponent implements OnInit {

  productsData:BPOProducts[]=[];
  productID = null;


  constructor(private custService:CustomersService) { }

  ngOnInit(): void {
    this.productID = this.custService.getProductID();


    this.custService.getSingleProductByID(this.productID).pipe()
    .subscribe(response =>{
      console.log('Banckend response ', response.message);
      this.productsData = response.data;

       console.log("Backend Response : DATA -> ",this.productsData);

    })

  }


}
