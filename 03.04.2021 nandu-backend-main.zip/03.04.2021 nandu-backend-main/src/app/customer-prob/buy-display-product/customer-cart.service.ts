import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Subject } from "rxjs";
import { first, map } from "rxjs/operators";
import { Router } from "@angular/router";
import { CustomerCart } from "../customercart.model";

@Injectable({ providedIn: "root" })
export class CustomerCartService{

  CustomerCart : CustomerCart[]=[];



  constructor(private http: HttpClient, private router: Router) {

  }

  addProductintoCustomerCart(productID,OrderDate,PlacedDate,DroppingDate){
    this.http.post<{message:string}>("http://localhost:3000/api/customercart/add-customer-cart",{productID,OrderDate,PlacedDate,DroppingDate})
    .subscribe(response =>{
      console.log('added to cart ',response.message);
    })
  }

 }
