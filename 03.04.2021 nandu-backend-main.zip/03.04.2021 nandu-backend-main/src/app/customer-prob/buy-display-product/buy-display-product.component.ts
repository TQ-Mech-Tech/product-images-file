import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { BPOProducts } from '../bpo-products.models';
import { CustomersService } from '../customers.service';
import { BuyDisplayProductDetailsComponent } from './buy-display-product-details/buy-display-product-details.component';
import { CustomerCartService } from './customer-cart.service';

@Component({
  selector: 'app-buy-display-product',
  templateUrl: './buy-display-product.component.html',
  styleUrls: ['./buy-display-product.component.css']
})
export class BuyDisplayProductComponent implements OnInit {

  grindingType = "Hard Grinding";


  // imageStyle = {
  //   'background-image':
  // }
  /**background-image: url(``); background-size:cover */

  ProductsData:BPOProducts[]=[];




  constructor(public dialog: MatDialog, private custService : CustomersService, private custCartService:CustomerCartService, private buyProductResponse: MatSnackBar) { }



  durationInSeconds = 5;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  addedtoCartResponseMassage(){
  
}




  ngOnInit(): void {

    this.custService.getProductsfromBPO()
    .subscribe(yourInfo =>{
      console.log('your products message from bpo ***\n ', yourInfo.message);
      // console.log("your products info ", yourInfo.productData);
      this.ProductsData = yourInfo.productData;
      console.log('angular data view ',this.ProductsData);



    })
  }
  product_value = 115;
  productKG = 5;

  /**
  this.date = new Date();
  this.date.setDate( this.date.getDate() + 3 );

   */


  addDays(date, days) {
    var result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }

  buytoCart(productIdValue){

    console.log('your product id is ',productIdValue.value);
    let orderDate = new Date();
    let placedDate = this.addDays(orderDate,1);

    let droppingDate = this.addDays(orderDate,3);

    console.log('Order date ',orderDate);
    console.log('Placed Date ',placedDate);
    console.log('droppingDate ',droppingDate);

    this.custCartService.addProductintoCustomerCart(productIdValue.value,orderDate,placedDate,droppingDate);
    
    this.buyProductResponse.open("Successfully added to Cart . . .", 'Your Done', {
      duration: this.durationInSeconds * 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
    });

  }

  openDialog(inputValue) {
    console.log("your product id is ",inputValue.value);

    this.custService.setSingleProductId(inputValue.value);
    // this.custUpdateservice.putCustUpdateId(inputValue.value);
    const dialogRef = this.dialog.open(BuyDisplayProductDetailsComponent);

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }
}
