import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyDisplayProductComponent } from './buy-display-product.component';

describe('BuyDisplayProductComponent', () => {
  let component: BuyDisplayProductComponent;
  let fixture: ComponentFixture<BuyDisplayProductComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyDisplayProductComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyDisplayProductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
