export interface BPOProducts{
  id:string;
  productname:string;
  grindingtype:string;
  weight:string;
  totalamount:string;
  imageurl:string;
  productstatus:string;
  detail:string;
}
