import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerProfileCerviceService {

  constructor() { }
  showSaveButtonPressResponse(holder){
    holder = "Your Profile Saved Successfully ! Thank You"
  }
}
