import { Component, OnInit } from '@angular/core';
import { CustomerProfileCerviceService } from '../customer-profile-cervice.service'
@Component({
  selector: 'app-dailog',
  templateUrl: './dailog.component.html',
  styleUrls: ['./dailog.component.css']
})
export class DailogComponent implements OnInit {

  showResponse;
  constructor(public getRespo:CustomerProfileCerviceService ) { }
  
  receivedmethod(data){
    data = this.getRespo.showSaveButtonPressResponse;
    this.showResponse = data
  }

  ngOnInit(): void {
  }

}
