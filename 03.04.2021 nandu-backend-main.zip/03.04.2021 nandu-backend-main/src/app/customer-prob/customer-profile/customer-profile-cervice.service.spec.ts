import { TestBed } from '@angular/core/testing';

import { CustomerProfileCerviceService } from './customer-profile-cervice.service';

describe('CustomerProfileCerviceService', () => {
  let service: CustomerProfileCerviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CustomerProfileCerviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
