import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, FormGroupName, Validators } from '@angular/forms'

import { CustomersService } from '../customers.service';
import {CustomerProfile} from '../customers.models';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { DailogComponent } from './dailog/dailog.component';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-customer-profile',
  templateUrl: './customer-profile.component.html',
  styleUrls: ['./customer-profile.component.css']
})
export class CustomerProfileComponent implements OnInit {

  customerProfileForm : FormGroup;

  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steakk'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];

  constructor(private custService:CustomersService, private _snackBar: MatSnackBar,public dialog: MatDialog) { }
  stateError = false;
  customerProfile : CustomerProfile;
  custProfileID : any;
  EditMode:boolean = false;

  durationInSeconds = 5;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


   responseSaveMessage:string;

showSaveButtonPressResponse(){
  this.dialog.open(DailogComponent);
}

  ngOnInit(): void {

    //Reactive Form approch
    this.customerProfileForm = new FormGroup({
      firstName : new FormControl(null,{validators: [ Validators.required, Validators.minLength(4)]}),
      middleName : new FormControl(null,{validators: [ Validators.required, Validators.minLength(4)]}),
      lastName : new FormControl(null,{validators: [ Validators.required, Validators.minLength(4)]}),
      address : new FormControl(null,{validators: [ Validators.required, Validators.minLength(15)]}),
      sectorNo : new FormControl(null, {validators: [ Validators.required, Validators.maxLength(5)] }),
      plotNo : new FormControl(null,{validators: [ Validators.required, Validators.maxLength(5)] }),
      state : new FormControl('',  Validators.required),
      dist : new FormControl('',Validators.required),
      tal : new FormControl('',Validators.required),
      city : new FormControl('',Validators.required),
      pinCode: new FormControl(null,{validators: [ Validators.required, Validators.maxLength(6)] })

    });
    this.getCustomerProfile();
    //ngOnInit() End here

     (() =>{
        this._snackBar.open("Your profile's data . . .", 'done', {
        duration: this.durationInSeconds * 1000,
        horizontalPosition: this.horizontalPosition,
        verticalPosition: this.verticalPosition,
      });
    })();


  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  getCustomerProfile(){
          //call getcustomerprofile from service and subscribe here

          this.custService.getCustomerProfile()
          .subscribe(custProfileData =>{
            console.log(custProfileData.editMode);
            console.log("customer message ",custProfileData.message);
            if(custProfileData.editMode){
              this.EditMode = custProfileData.editMode;
              this.customerProfile = {
                id : custProfileData.data.id,
                firstname : custProfileData.data.firstname,
                middlename : custProfileData.data.middlename,
                lastname : custProfileData.data.lastname,
                address : custProfileData.data.address,
                sectorno : custProfileData.data.sectorno,
                plotno : custProfileData.data.plotno,
                state : custProfileData.data.state,
                dist : custProfileData.data.dist,
                tal : custProfileData.data.tal,
                city : custProfileData.data.city,
                pin : custProfileData.data.pin,
                mob : custProfileData.data.mob,
                customerID : custProfileData.data.custID
              }
              console.log('your id type of ', typeof this.customerProfile.id, this.customerProfile.id);
              this.custProfileID = this.customerProfile.id;
              this.customerProfileForm.setValue({
                firstName : this.customerProfile.firstname,
                middleName : this.customerProfile.middlename,
                lastName : this.customerProfile.lastname,
                address : this.customerProfile.address,
                sectorNo : this.customerProfile.sectorno,
                plotNo : this.customerProfile.plotno,
                state : this.customerProfile.state,
                dist : this.customerProfile.dist,
                tal : this.customerProfile.tal,
                city : this.customerProfile.city,
                pinCode : this.customerProfile.pin
              });
            }
          });
    }

  onSave(){
    if(this.customerProfileForm.invalid){
      console.log('your form is not valid');
      return;
    }

    if(this.EditMode){
      if(this.customerProfileForm.invalid){
        console.log('your form is not valid');
        return;
      }

      this.custService.editCustomerProfile( this.custProfileID,this.customerProfileForm.value.firstName,
        this.customerProfileForm.value.middleName,
        this.customerProfileForm.value.lastName,
        this.customerProfileForm.value.address,
        this.customerProfileForm.value.sectorNo,
        this.customerProfileForm.value.plotNo,
        this.customerProfileForm.value.state,
        this.customerProfileForm.value.dist,
        this.customerProfileForm.value.tal,
        this.customerProfileForm.value.city,
        this.customerProfileForm.value.pinCode)
        .subscribe(updtedData =>{
          console.log(updtedData.message);
        })
        return;

    }

    this.custService.addCustomerProfile(
      this.customerProfileForm.value.firstName,
      this.customerProfileForm.value.middleName,
      this.customerProfileForm.value.lastName,
      this.customerProfileForm.value.address,
      this.customerProfileForm.value.sectorNo,
      this.customerProfileForm.value.plotNo,
      this.customerProfileForm.value.state,
      this.customerProfileForm.value.dist,
      this.customerProfileForm.value.tal,
      this.customerProfileForm.value.city,
      this.customerProfileForm.value.pinCode
    );


    /** firstName :
      middleName :
      lastName :
      address :
      sectorNo :
      plotNo :
      state :
      dist :
      tal :
      city :
      pinCode: */


  }



}

function DialogElementsExampleDialog(DialogElementsExampleDialog: any) {
  throw new Error('Function not implemented.');
}

