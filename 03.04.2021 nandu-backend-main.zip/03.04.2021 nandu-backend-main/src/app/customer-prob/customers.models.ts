export interface CustomerProfile{
  id:string;
  firstname:string;
  middlename:string;
  lastname:string;
  address:string;
  sectorno:string;
  plotno:string;
  state:string;
  dist:string;
  tal:string;
  city:string;
  pin:string;
  mob:string;
  customerID:string;
}
