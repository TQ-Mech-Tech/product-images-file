import { Component, OnInit,Input } from '@angular/core';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { CustomerCart } from '../customercart.model';
import { CustomersService } from '../customers.service';
import { trigger, state, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'app-customer-cart',
  templateUrl: './customer-cart.component.html',
  styleUrls: ['./customer-cart.component.css'],
  animations: [
      trigger('EnterLeave', [
      state('flyIn', style({ transform: 'translateX(0)' })),
      // transition(':enter', [
      //   style({ transform: 'translateX(-100%)' }),
      //   animate('0.5s 300ms ease-in')
      // ]),
      transition(':leave', [
        animate('0.6s 300ms ease-out', style({ transform: 'translateX(100%)' }))
      ])
    ])
  ]
})


export class CustomerCartComponent implements OnInit {

  isCartEmpty:Boolean = false;
  cartData:CustomerCart[]=[];

  constructor(private custService:CustomersService ,private _snackBar: MatSnackBar) {

  }

  durationInSeconds = 5;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';

  removeItem() {
    this.cartData.length -= 1;
  }


  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6;
  }
  check :any =112;
  disableReadOnlyValue = true;
  allProdPrice=0;

  ngOnInit(): void {
    this.getCustomerProductsInfo();

  }

  getCustomerProductsInfo(){
    this.custService.getCustCartProductinfo().subscribe(result =>{
      console.log(result.message);
      this.cartData = result.cartInfo ;
      console.log('your cart data ',this.cartData);
      this.allProdPrice = result.allProdPrice;
    });
  }

  trash(productID){
    this.cartData.length -= 1;
    this._snackBar.open("Product was trashed. . .", 'Your Done', {
      duration: this.durationInSeconds * 1000,
      horizontalPosition: this.horizontalPosition,
      verticalPosition: this.verticalPosition,
      
    });
  
if(productID !== null){
   this.isCartEmpty = true;
}

   console.log("your trash products value ",productID.value);
   this.custService.trashthisProductdelete(productID.value)
   .subscribe(result =>{
     console.log("http delete message ",result.message);
     console.log("your result form backend ",result.data);


    this.getCustomerProductsInfo();
   })
  }

}
