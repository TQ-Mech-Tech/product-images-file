import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarHorizontalPosition, MatSnackBarVerticalPosition } from '@angular/material/snack-bar';
import { CustomersService } from '../customers.service';

interface Food {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-customer-buying',
  templateUrl: './customer-buying.component.html',
  styleUrls: ['./customer-buying.component.css'],
  providers: [DatePipe]
})
export class CustomerBuyingComponent implements OnInit {

  datepickerStyles = {'color':'blue','margin-top':'2px'}
  selectedDte:Date= new Date();
  dayofDates=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
//           =[0,1,2,3,4,5,6]
  ID = null;
  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 2 && day !== 4 && day !== 5;
  }



  constructor( private _snackBar: MatSnackBar,private datePipe: DatePipe, private custService:CustomersService) { }

  durationInSeconds = 5;
  horizontalPosition: MatSnackBarHorizontalPosition = 'center';
  verticalPosition: MatSnackBarVerticalPosition = 'top';


  disableReadOnlyValue=true;

  foods: Food[] = [
    {value: 'steak-0', viewValue: 'Steak'},
    {value: 'pizza-1', viewValue: 'Pizza'},
    {value: 'tacos-2', viewValue: 'Tacos'}
  ];

  grindProductsNames=[];
  grindProductsTypes=[];
  grindProductsWeight=[];
 customerBuyingForm:FormGroup;

/**
 *  ngOnInit(): void {
    // You can use whatever format you like
    // see https://angular.io/api/common/DatePipe#pre-defined-format-options
    this.currentDate = this.datePipe.transform(this.currentDate, 'dd-MM-yyyy');

  }
  //3/27/2021
 */
  currentDate:any = this.datePipe.transform(new Date());//,'MM/dd/yyyy'

  ngOnInit(): void {
    console.log('your current date ',this.currentDate)
    this.customerBuyingForm = new FormGroup({
      choosedate:new FormControl(this.currentDate, {validators:[Validators.required]}),
      chooseproduct:new FormControl( null , {validators:[Validators.required]}),
      chooseGrindingType:new FormControl( null , {validators:[Validators.required]}),
      weight:new FormControl( null , {validators:[Validators.required]}),
      price:new FormControl( null , {validators:[Validators.required]}),
      servicecharge:new FormControl( null , {validators:[Validators.required]}),
      pickupdate:new FormControl( null , {validators:[Validators.required]}),
      droppingDate:new FormControl( null , {validators:[Validators.required]}),
    });


    this.getProductName();
  }

  addedtoCartResponseMassage(){
    this._snackBar.open("Successfully added to Cart . . .", 'Your Done', {
    duration: this.durationInSeconds * 1000,
    horizontalPosition: this.horizontalPosition,
    verticalPosition: this.verticalPosition,
  });
}

addDays(date, days) {
  let result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

cutDays(date,days){
  let result = new Date(date);
  result.setDate(result.getDate() - days);
  return result;
}

datePicked(){
  console.log("your date is ",this.customerBuyingForm.controls['pickupdate'].value);

   this.selectedDte = this.customerBuyingForm.controls['pickupdate'].value;
  let todaysDate = new Date();
  console.log("selected date ", this.selectedDte," todays date",todaysDate);
  console.log("checking dates with day, month, year ",this.selectedDte.getDay() === todaysDate.getDay()," month ",this.selectedDte.getMonth() === todaysDate.getMonth(),' year ',this.selectedDte.getFullYear() === todaysDate.getFullYear());
  console.log("your selected date >= todays date",this.selectedDte.getTime() === todaysDate.getTime());
  if( this.selectedDte.getTime() > todaysDate.getTime() || (this.selectedDte.getDay() === todaysDate.getDay() && this.selectedDte.getMonth() === todaysDate.getMonth() && this.selectedDte.getFullYear() === todaysDate.getFullYear())){
    console.log("selected date is valid");
    let dayofSelectedDate=this.selectedDte.getDay();
    console.log('your day of selected date ',dayofSelectedDate);
    if(dayofSelectedDate == 1)
    {
      //monday codding
      //let droppingDate = this.addDays(orderDate,3);
      //this.datePipe.transform(new Date())
      this.customerBuyingForm.controls['droppingDate'].setValue(this.datePipe.transform(this.addDays(this.selectedDte,2)));
    }
    else if(dayofSelectedDate == 3){
      //wednesday codding
      this.customerBuyingForm.controls['droppingDate'].setValue(this.datePipe.transform(this.addDays(this.selectedDte,3)));
    }
    else if(dayofSelectedDate == 6){
      // saturday codding
      this.customerBuyingForm.controls['droppingDate'].setValue(this.datePipe.transform(this.addDays(this.selectedDte,2)));
    }
    /**['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            =[0,1,2,3,4,5,6] */
    //date.getDay();
  }
  else if(this.selectedDte <= todaysDate){
    console.log("selected date is invalid");
  }
}

  getProductName(){
    //getGrindProductNamesOnly
    this.custService.getGrindProductNamesOnly()
    .subscribe(result =>{
     console.log('grinding products ',result.data);
     this.grindProductsNames = result.data.map(x =>{ return x.productName});
     console.log('your only grinding products names ',this.grindProductsNames);
     this.grindProductsTypes = result.data.map(x =>{return x.grindingType});
     console.log("your grinding type is ",this.grindProductsTypes);
     this.grindProductsWeight = result.data.map(x =>{return x.weight});
     console.log('your grind products weight is ',this.grindProductsWeight);

    });
  }

  calculateCustGrindProd(){

    let name= this.customerBuyingForm.controls['chooseproduct'].value;
    let type =this.customerBuyingForm.controls['chooseGrindingType'].value;
    let weight = this.customerBuyingForm.controls['weight'].value;
//calculateCustomerGrindingProduct
    console.log(`your name ${name}, your grindType ${type}, your weight ${weight}`);
    this.custService.calculateCustomerGrindingProduct(name,type,weight)
    .subscribe(result =>{
      this.customerBuyingForm.controls['price'].setValue(result.data);
      console.log(`your data ${result.data} and id ${result.id}`);
      console.log("your typo of _id ",typeof result.id);
      this.ID = result.id;
    })

  }

}
