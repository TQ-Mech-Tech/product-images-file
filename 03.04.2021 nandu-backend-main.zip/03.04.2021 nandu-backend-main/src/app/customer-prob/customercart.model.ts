export interface CustomerCart{
  id:string,
  products:[{
    id:string,
    name:string,
    type:string,
    price:string,
    tax:string,
    weight:string,
    amount:string
  }],
  totalWeight:string,
  deliveryCharge:string,
  totalTax:string,
  totalAmount:string,
  userId:string
}
