import { Component, OnInit,ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import {MatAccordion} from '@angular/material/expansion';
import { RefundRequestResponseComponent } from './refund-request-response/refund-request-response.component';

interface Product {
  id: string;
  productName: string;
  grindingType: string;
  weight: string;
  price: string;
  servicesCharge: string;
}


interface OrderData {
  id: string;
  date: string;
  product: Product[];
  pickUpDate: string;
  dropingDate: string;
  totalWeight: string;
  deliveryCharge: string;
  totalAmount: string;
  orderTrack:string;
  orderStatus:string;
}
@Component({
  selector: 'app-customer-order',
  templateUrl: './customer-order.component.html',
  styleUrls: ['./customer-order.component.css']
})


export class CustomerOrderComponent implements OnInit {


  /* Css Style properties*/

  inputeStyle = {
    'color': 'green',
    'margin-top':'10vh'
    }

    
    constructor(public dialog: MatDialog) {}

  @ViewChild(MatAccordion) accordion: MatAccordion;

  displayedColumns2: string[] = ['PickUpDate', 'DroppingDate', 'TotalWeight', 'DeliveryCharge'];
  displayedColumns: string[] = ['ProductName','GrindingType','Weight','Price','ServiceCharge'];
  displayColumnsTable2:string[] =['PickupDate'];
  orderDetails:OrderData[]=[{
     id: '1',
   date: "23/Jan/2021",
   product:[{id:'12',productName:"lokvan wheat",grindingType:"hard grinding",weight:"11 kg",price:"77",servicesCharge:"22"},
   {id:'13',productName:"wheat",grindingType:"lean grinding",weight:"15 kg",price:"105",servicesCharge:"30"},
   {id:'14',productName:"wheat",grindingType:"fine grinding",weight:"18 kg",price:"126",servicesCharge:"36"},
   {id:'13',productName:"wheat",grindingType:"leansd grinding",weight:"15 kg",price:"105",servicesCharge:"30"}],
   pickUpDate:"27/jan/2021",
   dropingDate:"30/jan/2021",
   totalWeight:"11 kg",
   deliveryCharge:"20",
   totalAmount:"127",
   orderTrack:"20",
   orderStatus:"pending"
 },
 {
   id: '2',
 date: "4/Feb/2021",
 product:[{id:'12',productName:"lokvan wheat",grindingType:"hard grinding",weight:"11 kg",price:"77",servicesCharge:"22"},
 {id:'13',productName:"wheat",grindingType:"lean grinding",weight:"15 kg",price:"105",servicesCharge:"30"},
 {id:'14',productName:"wheat",grindingType:"fine grinding",weight:"18 kg",price:"126",servicesCharge:"36"}],
 pickUpDate:"4/Feb/2021",
 dropingDate:"6/Feb/2021",
 totalWeight:"11 kg",
 deliveryCharge:"20",
 totalAmount:"657",
 orderTrack:"100",
 orderStatus:"paid"
 }]
 
   disabled = true;
   invert = false;
   count = 0;
   counting_values = this.orderDetails.length;
   datep = "12 jan 2021"
   step = 1;
   thumbLabel = false;
   totalMoney = "232";
   value = 50;
   vertical = false;
   disableReadOnlyValue = true;
   orderStatus = "Paid";

  ngOnInit(): void {
    console.log(typeof(this.orderDetails))
  }

  getyourId(data:string){
    console.log('your id is ',data);
    this.dialog.open(RefundRequestResponseComponent);
  }

}
