import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RefundRequestResponseComponent } from './refund-request-response.component';

describe('RefundRequestResponseComponent', () => {
  let component: RefundRequestResponseComponent;
  let fixture: ComponentFixture<RefundRequestResponseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RefundRequestResponseComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RefundRequestResponseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
