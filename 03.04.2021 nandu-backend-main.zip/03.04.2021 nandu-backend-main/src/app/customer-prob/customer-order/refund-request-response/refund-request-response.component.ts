import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-refund-request-response',
  templateUrl: './refund-request-response.component.html',
  styleUrls: ['./refund-request-response.component.css']
})
export class RefundRequestResponseComponent implements OnInit {

 
 
  ngOnInit(): void {
  }

}
