import { Component } from '@angular/core';
import { Subscription } from 'rxjs';
import { MediaObserver, MediaChange} from '@angular/flex-layout'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent 
{
  title = 'basic-project'




  // mediasub:Subscription;
  // asObservable: any;
  // constructor(public mediaObserver:MediaObserver ){}

//   ngOnInit(){
//    this.mediasub = this.mediaObserver

// ngOnDestroy(){

}

