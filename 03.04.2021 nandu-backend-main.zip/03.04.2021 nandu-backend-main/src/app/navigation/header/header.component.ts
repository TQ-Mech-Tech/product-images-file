import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Output() closeSidenav = new EventEmitter<void>();

  aboutus ;
  whatwedo ;
  ourcustomerstory ;

  constructor() { }

  ngOnInit(): void {


  }


    
  toAboutUs() {
    document.getElementById('about-us').scrollIntoView({behavior:'smooth'})
  }

  toWhatWeDo(){
    document.getElementById('whatwedo').scrollIntoView({behavior:'smooth'})
  }

  toOurCustomerStory(){
    document.getElementById('ourcustomerstory').scrollIntoView({behavior:'smooth'})
  }

  onClose(){
    this.closeSidenav.emit();
   
  //  this.aboutus = document.getElementById('about-us').scrollIntoView({behavior:'smooth'})
  //  this.whatwedo = document.getElementById('whatwedo').scrollIntoView({behavior:'smooth'})
  //  this.ourcustomerstory = document.getElementById('ourcustomerstory').scrollIntoView({behavior:'smooth'})
}
   
    
    
  }


