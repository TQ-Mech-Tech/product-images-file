import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DELIVERYNavComponent } from './delivery-nav.component';

describe('DELIVERYNavComponent', () => {
  let component: DELIVERYNavComponent;
  let fixture: ComponentFixture<DELIVERYNavComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DELIVERYNavComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DELIVERYNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
