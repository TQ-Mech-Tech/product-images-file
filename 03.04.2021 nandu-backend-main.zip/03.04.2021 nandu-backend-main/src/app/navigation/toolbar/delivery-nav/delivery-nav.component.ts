import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-nav',
  templateUrl: './delivery-nav.component.html',
  styleUrls: ['./delivery-nav.component.css']
})
export class DELIVERYNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
