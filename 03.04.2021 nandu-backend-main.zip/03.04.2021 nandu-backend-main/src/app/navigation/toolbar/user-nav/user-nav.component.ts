import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-nav',
  templateUrl: './user-nav.component.html',
  styleUrls: ['./user-nav.component.css']
})
export class USERNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  toAboutUs(){
    document.getElementById('about-us').scrollIntoView({behavior:'smooth'})
  }

  toWhatWeDo(){
    document.getElementById('whatwedo').scrollIntoView({behavior:'smooth'})
  }

  toOurCustomerStory(){
    document.getElementById('ourcustomerstory').scrollIntoView({behavior:'smooth'})
  }
}
