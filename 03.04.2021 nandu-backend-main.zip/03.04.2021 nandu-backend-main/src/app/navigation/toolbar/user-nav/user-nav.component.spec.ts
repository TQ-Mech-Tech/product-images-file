import { ComponentFixture, TestBed } from '@angular/core/testing';

import { USERNavComponent } from './user-nav.component';

describe('USERNavComponent', () => {
  let component: USERNavComponent;
  let fixture: ComponentFixture<USERNavComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ USERNavComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(USERNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
