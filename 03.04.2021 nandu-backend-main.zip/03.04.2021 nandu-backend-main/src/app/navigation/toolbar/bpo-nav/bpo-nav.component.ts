import { Component, EventEmitter, OnInit, Output  } from '@angular/core';

@Component({
  selector: 'app-bpo-nav',
  templateUrl: './bpo-nav.component.html',
  styleUrls: ['./bpo-nav.component.css']
})
export class BPONavComponent implements OnInit {
  @Output() closeSidenav = new EventEmitter<void>();
  constructor() { }

  ngOnInit(): void {
  }

  onClose(){
    this.closeSidenav.emit();
}
   
}
