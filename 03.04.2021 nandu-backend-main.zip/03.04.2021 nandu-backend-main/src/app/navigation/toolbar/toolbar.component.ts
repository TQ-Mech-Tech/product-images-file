
import { Component, EventEmitter, OnInit, Output } from '@angular/core';


@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.css']
})
export class ToolbarComponent implements OnInit {

  user =true;
  bpo = false;
  delivery = false;

  @Output() sidenavToggle = new EventEmitter<void>();

  constructor() { }

  ngOnInit(): void {


   }

  onToggleSidenav(){
    this.sidenavToggle.emit();
  }

  onUser(){
    if( this.user =! this.user){
      return
    }
  }

  onBpo(){
    if(this.bpo =! this.bpo){
      return;
    }
  }
  onDelivery(){
    if(this.delivery =! this.delivery){
      return;
    }
  }

}
