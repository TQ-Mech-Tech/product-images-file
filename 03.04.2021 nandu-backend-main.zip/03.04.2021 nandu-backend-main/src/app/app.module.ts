import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {ReactiveFormsModule, FormsModule} from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

// For MDB Angular Free
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatButtonModule} from '@angular/material/button';
import {MatMenuModule} from '@angular/material/menu';
import {MatIconModule} from '@angular/material/icon';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatListModule} from '@angular/material/list'
import {MatCardModule} from '@angular/material/card';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input'
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatSelectModule} from '@angular/material/select';
import {MatTabsModule} from '@angular/material/tabs';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatBadgeModule} from '@angular/material/badge';
import {MatSliderModule} from '@angular/material/slider';
import {MatDividerModule} from '@angular/material/divider';
import { FlexLayoutModule } from '@angular/flex-layout';
import {MatTableModule} from '@angular/material/table';
import {MatDialogModule} from '@angular/material/dialog';
import {MatPaginatorModule} from '@angular/material/paginator';

// User UI Imports
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { AppRoutingModule } from './app-routing.component';
import { WelcomeComponent } from './welcome/welcome.component';

// BPO section imports
import { ForgetPasswordComponent } from './auth/forget-password/forget-password.component';
import { ChangePasswordComponent } from './auth/change-password/change-password.component';
import { HeaderComponent } from './navigation/header/header.component';
import { ToolbarComponent } from './navigation/toolbar/toolbar.component';
import { CustomerProfileComponent } from './customer-prob/customer-profile/customer-profile.component';

import { CustomerOrderComponent } from './customer-prob/customer-order/customer-order.component';
import { CustomerBuyingComponent } from './customer-prob/customer-buying/customer-buying.component';
import { CustomerCartComponent } from './customer-prob/customer-cart/customer-cart.component';
import { MatNativeDateModule } from '@angular/material/core';
import { FooterComponent } from './footer/footer.component';


import { BuyDisplayProductComponent } from './customer-prob/buy-display-product/buy-display-product.component';
import { BuyDisplayProductDetailsComponent } from './customer-prob/buy-display-product/buy-display-product-details/buy-display-product-details.component';
import { BPOauthLoginComponent } from './BPOControll/bpoauth-login/bpoauth-login.component';
import { DGProfileComponent } from './BPOControll/dg-profile/dg-profile.component';
import { DGResponsibleForAreaComponent } from './BPOControll/dg-responsible-for-area/dg-responsible-for-area.component';
import { DGSignUpComponent } from './BPOControll/dg-sign-up/dg-sign-up.component';
import { ViewCustomerProfileTableComponent } from './BPOControll/view-customer-profile-table/view-customer-profile-table.component';
import { UpdateCustomerProfileComponent } from './BPOControll/view-customer-profile-table/update-customer-profile/update-customer-profile.component';
import { DgMainWindowComponent } from './DeliveryGuyControl/DeliveryAuth/dg-main-window/dg-main-window.component';
import { DgloginComponent } from './DeliveryGuyControl/DeliveryAuth/dglogin/dglogin.component';
import { AddProductServicesComponent } from './BPOControll/add-product-services/add-product-services.component';
import { ViewProductServicesComponent } from './BPOControll/view-product-services/view-product-services.component';
import { CustomerViewProfileService } from './BPOControll/view-customer-profile-table/view-customer-profile.service';
import { ViewApprovedRefundComponent } from './BPOControll/fix-customer-refund/view-approved-refund/view-approved-refund.component';
import { FixCustomerRefundComponent } from './BPOControll/fix-customer-refund/fix-customer-refund.component';
import { ViewCustomerOrderProductDetailsComponent } from './BPOControll/view-customer-order/view-customer-order-product-details/view-customer-order-product-details.component';
import { ViewCustomerOrderComponent } from './BPOControll/view-customer-order/view-customer-order.component';
import { ViewCustomerOrderService } from './BPOControll/view-customer-order/view-customer-order.service';
import { ViewDgSignUpComponent } from './BPOControll/dg-sign-up/view-dg-sign-up/view-dg-sign-up.component';
import { ViewResponsibleComponent } from './BPOControll/dg-responsible-for-area/view-responsible/view-responsible.component';
import { ViewDgProfileComponent } from './BPOControll/dg-profile/view-dg-profile/view-dg-profile.component';
import { ViewCancleRefundComponent } from './BPOControll/fix-customer-refund/view-cancle-refund/view-cancle-refund.component';
import { SmallDeviceNotSupportedComponent } from './BPOControll/small-device-not-supported/small-device-not-supported.component';
import { PageFourZeroFourNotFoundComponent } from './page-four-zero-four-not-found/page-four-zero-four-not-found.component';
import { ProblemOccuredComponent } from './problem-occured/problem-occured.component';
import { BPONavComponent } from './navigation/toolbar/bpo-nav/bpo-nav.component';
import { USERNavComponent } from './navigation/toolbar/user-nav/user-nav.component';
import { DELIVERYNavComponent } from './navigation/toolbar/delivery-nav/delivery-nav.component';
import { MillInfoComponent } from './BPOControll/mill-info/mill-info.component';
import { PaymentInfoComponent } from './BPOControll/payment-info/payment-info.component';
import { AddMillComponent } from './DeliveryGuyControl/DeliveryAuth/dg-main-window/add-mill/add-mill.component';
import { AddPaymentComponent } from './DeliveryGuyControl/DeliveryAuth/dg-main-window/add-payment/add-payment.component';
import { AddGridingProductComponent } from './BPOControll/add-griding-product/add-griding-product.component';
import { DailogComponent } from './customer-prob/customer-profile/dailog/dailog.component';
import { RefundRequestResponseComponent } from './customer-prob/customer-order/refund-request-response/refund-request-response.component';



//MatButtonModule
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    SignupComponent,
    WelcomeComponent,
    ForgetPasswordComponent,
    ChangePasswordComponent,
    HeaderComponent,
    ToolbarComponent,
    CustomerProfileComponent,
    CustomerOrderComponent,
    CustomerBuyingComponent,
    CustomerCartComponent,
    FooterComponent,
    BuyDisplayProductComponent,
    BuyDisplayProductDetailsComponent,
    BPOauthLoginComponent,
    DGProfileComponent,
    DGResponsibleForAreaComponent,
    DGSignUpComponent,
    ViewCustomerProfileTableComponent,
    UpdateCustomerProfileComponent,
    DgMainWindowComponent,
    DgloginComponent,
    AddProductServicesComponent,
    ViewProductServicesComponent,
    ViewApprovedRefundComponent,
    FixCustomerRefundComponent,
    ViewCustomerOrderProductDetailsComponent,
    ViewCustomerOrderComponent,
    ViewDgSignUpComponent,
    ViewResponsibleComponent,
    ViewDgProfileComponent,
    ViewCancleRefundComponent,
    SmallDeviceNotSupportedComponent,
    PageFourZeroFourNotFoundComponent,
    ProblemOccuredComponent,
    BPONavComponent,
    USERNavComponent,
    DELIVERYNavComponent,
    MillInfoComponent,
    PaymentInfoComponent,
    AddPaymentComponent,
    AddMillComponent,
    AddGridingProductComponent,
    DailogComponent,
    RefundRequestResponseComponent

  ],


  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    HttpClientModule,

    // below are mat component
    MatToolbarModule,
    MatButtonModule,
    MatMenuModule,
    MatIconModule,
    MatSidenavModule,
    AppRoutingModule,
    FlexLayoutModule,
    MatListModule,
    ReactiveFormsModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatTooltipModule,
    MatSelectModule,
    MatTabsModule,
    MatGridListModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSnackBarModule,
    MatExpansionModule,
    MatBadgeModule,
    MatSliderModule,
    MatDividerModule,
    MatDialogModule,
    MatTableModule,
    MatPaginatorModule,
  


  ],
  providers: [MatNativeDateModule,CustomerViewProfileService,ViewCustomerOrderService],
  bootstrap: [AppComponent]
})
export class AppModule { }
