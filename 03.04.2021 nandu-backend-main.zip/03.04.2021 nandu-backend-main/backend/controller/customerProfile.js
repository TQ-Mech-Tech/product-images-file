const CustomerProfile = require('../models/customerProfile');

exports.addCustomerProfile = (req,res,next) =>{
  if(!req.cust){
    return res.status(401).json({
      message:"You are Unauthorized !"
    })
  }
//post request
    const firstname = req.body.firstname;
    const middlename = req.body.middlename;
    const lastname = req.body.lastname;
    const address = req.body.address;
    const sectorno = req.body.sectorno;
    const plotno = req.body.plotno;
    const state = req.body.state;
    const distict = req.body.dist;
    const taluka = req.body.tal;
    const city = req.body.city;
    const pinCode = req.body.pin;

    const custProfile = new CustomerProfile({
      firstName : firstname,
      middleName : middlename,
      lastName : lastname,
      address : address,
      sectorNo : sectorno,
      plotNo : plotno,
      state : state,
      dist : distict,
      tal : taluka,
      city : city,
      pin : pinCode,
      mob : req.cust.mobile,
      customerId: req.cust._id
    });

    custProfile.save()
    .then( result =>{
      res.status(201).json({
        message:"your data has been saved successfully",
        data:result
      });
    })
    .catch(err => {
      console.log(err);
      res.status(511).json({
        message:"Network Authentication Required, also check below Error",
        errorMessage:err.errorMessage
      })
    });

}

exports.getCustomerProfile = (req,res,next) =>{
//get request

      if(!req.cust){
        //Serious Note :user authenticatin later jwt will replace here precisely
        return res.status(421).json({
          message:"Misdirected Request found",
          data:null,
          editMode: false
        })
      }

      CustomerProfile.findOne({customerId: req.cust._id})
      .then(custProfile =>{
        if(!custProfile){
          return res.status(404).json({message:"Not Available",
          data:null,
          editMode: false});
        }
       const custProfInfo = {
          id : custProfile._id,
          firstname : custProfile.firstName,
          middlename : custProfile.middleName,
          lastname : custProfile.lastName,
          address : custProfile.address,
          sectorno : custProfile.sectorNo,
          plotno : custProfile.plotNo,
          state : custProfile.state,
          dist : custProfile.dist,
          tal : custProfile.tal,
          city : custProfile.city,
          pin : custProfile.pin,
          mob : custProfile.mob,
          custID : null
        }
        res.status(200).json({
          message:"Customer Founded",
          data: custProfInfo,
          editMode: true
        });

      })
      .catch(err => {
      console.log(err);
      res.status(404).json({
        message:`not found, ERROR ${err.errorMessage}`,
        data:null,
        editMode: false
      });

    });
}

exports.updateCustomer = (req,res,next) =>{

  const CUSTID = req.params.custprofileid;
    /**const prodId = req.body.productId;
    const updatedTitle = req.body.title;
    const updatedPrice = req.body.price;
    const updatedImageUrl = req.body.imageUrl;
    const updatedDesc = req.body.description;

    Product.findById(prodId)
      .then(product => {
        product.title = updatedTitle;
        product.price = updatedPrice;
        product.description = updatedDesc;
        product.imageUrl = updatedImageUrl;
        return product.save();
      })
      .then(result => {
        console.log('UPDATED PRODUCT!');
        res.redirect('/admin/products');
      })
      .catch(err => console.log(err)); */

      const updatedfirstname = req.body.firstname;
    const updatedmiddlename = req.body.middlename;
    const updatedlastname = req.body.lastname;
    const updatedaddress = req.body.address;
    const updatedsectorno = req.body.sectorno;
    const updatedplotno = req.body.plotno;
    const updatedstate = req.body.state;
    const updateddistict = req.body.dist;
    const updatedtaluka = req.body.tal;
    const updatedcity = req.body.city;
    const updatedpinCode = req.body.pin;
    const updatedmob = req.cust.mobile;
   // const custID = req.cust._id;
  console.log(req.params.custprofileid);

  if(req.cust){
    CustomerProfile.findOne({_id : CUSTID,customerId : req.cust._id}).then(custProfile =>{

      custProfile.firstName = updatedfirstname;
      custProfile.middleName = updatedmiddlename;
      custProfile.lastName = updatedlastname;
      custProfile.address = updatedaddress;
      custProfile.sectorNo = updatedsectorno;
      custProfile.plotNo = updatedplotno;
      custProfile.state = updatedstate;
      custProfile.dist = updateddistict;
      custProfile.tal = updatedtaluka;
      custProfile.city = updatedcity;
      custProfile.pin = updatedpinCode;
      custProfile.mob = updatedmob;
      custProfile.customerId = req.cust._id;
      // return product.save();
      return custProfile.save();
    })
    .then(result =>{
      console.log(result)
    })
    .catch();
  }
  res.status(202).json({
    message:'content updated successfully'
  })
}
