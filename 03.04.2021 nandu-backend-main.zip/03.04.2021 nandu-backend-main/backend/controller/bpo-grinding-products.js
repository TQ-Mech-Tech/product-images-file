const { error } = require('selenium-webdriver');
const GrindingProduct = require('../models/grindingProduct');

exports.addGrindingProducts = (req,res,next)=>{

  if(!req.bpouser){
    return res.status(401).json({
      message:"you are not authorized to do so.",
      data: "your login credential not valid"
    });
  }

  const prodName = req.body.productname;
  const grindingType = req.body.grindingtype;
  const weight = req.body.weight;
  const price = req.body.price;
  const serviceCharge = req.body.serviceCharge;
  const totalAmount = req.body.totalAmount;

  console.log("your grinding type product is ",prodName);

  //assigning values into model
  const grindProdInfo = new GrindingProduct({
    productName : prodName,
    grindingType : grindingType,
    weight : weight,
    price:price,
    serviceCharge : serviceCharge,
    totalAmount : totalAmount,
    bpoUserID : req.bpouser._id
  });

  grindProdInfo.save()
  .then(result =>{
    res.status(201).json({
      message:"product data stored successfully",
      data:result
    })
  })
  .catch(error =>{
    res.status(501).json({
      message:"you are unathorized for this action",
      data:error
    })
  })

}

exports.getGrindingProducts = (req,res,next)=>{
  GrindingProduct.find()
  .then(grindProd =>{
    console.log("your grinding product is ",grindProd);
    res.status(200).json({
      data:grindProd
    })

  })
  .catch(error =>{
    console.log("your error ",error);
  })

}

exports.calculatCustomerGrindingProducts = (req,res,next)=>{
  console.log(`your grind prod name ${req.body.name}, type ${req.body.type}, weight ${req.body.weight}`);

  GrindingProduct.findOne({productName:req.body.name,grindingType:req.body.type,weight:req.body.weight})
  .select('-bpoUserID -productName -grindingType -weight -price -serviceCharge -__v')
  .then(founded =>{
    console.log('your founded product is ',founded);
    res.status(200).json({
      data:founded.totalAmount,
      id:founded._id

    })
  })
  .catch(error =>{
    res.status(401).json({
      data:error,
      id:null
    })
  })
  console.log("your Calculated customer method is calling successfully");
}
