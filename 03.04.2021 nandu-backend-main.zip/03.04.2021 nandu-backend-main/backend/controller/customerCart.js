const CustomerCart = require('../models/customerCart');
// const product = require('../models/product');0
const Products = require('../models/product');
const mongoose = require('mongoose');

exports.addCustomerCart = (req,res,next) =>{
/**productID,OrderDate,PlacedDate,DroppingDate */

/**we need to delete all old product from customer's cart if someone remained the cart as it is. */
  const productId = req.body.productID;
  const orderDate = req.body.OrderDate;
  const placedDate = req.body.PlacedDate;

  const droppingDate = req.body.DroppingDate;
  let productData = [];
  let Oldproducts =[];
  let deliveryCharged = 2;//₹ defined first place, there are other place too, where this tech define
  let TotalWeight = 0;
  let DeliveryCharge = 0;
  let TotalAmount = 0;
  let productTax =0;
  let totalTaxAmount = 0;
  let updatedCartItems =[];

  if(!req.cust){
    return res.status(401).json({
      message:"You are Unauthorized !"
    })
  }
  //in below lines of code which product you wanna purchase is taking from DB.
  // console.log("your product id is\t",productId);
  Products.findById(productId).lean().select('-serviceCharge -__v -surCharge -sGST -cGST -imageUrl -productStatus -detail -bpoID')
  .then(findProduct =>{
    let {price,totalAmount} = findProduct;
    productTax = +totalAmount - +price;
    console.log('original : ', findProduct);
    productData = findProduct;
    productData['tax'] = productTax.toFixed(2);
    console.log('founded product is : ',productTax,typeof productData, productData);
    return CustomerCart.findOne({userID:req.cust._id});
  })
  .then(productsInCart =>{
    // console.log('founded product is : ', productData);
    let {weight,totalAmount,tax} = productData;
    let DeliCharged = +weight * deliveryCharged;

    if(!productsInCart){
      //push first products in cart
      console.log('your cart is empty (',productsInCart,')',' putting first element into cart ');
      const cartElement = new CustomerCart({

        products: productData,
        totalWeight:weight,
        deliveryCharge:DeliCharged,
        totalTax:tax,
        totalAmount : +totalAmount + DeliCharged,
        userID:req.cust._id
      });

      console.log("your new cart is supposed to set ",cartElement);
      cartElement.save()
      .then(result =>{
        console.log('your cart result is ',result);
        res.status(201).json({
          message:"added to cart !"
        });
      });
    }

    else{
      console.log("founded customer's cart id ",productsInCart._id, productsInCart);
      //pushing multiple products into the cart
      //productsInCart/** this variable have all available cart */
      console.log("your cart has some products");
      Oldproducts = productsInCart.products;
       TotalWeight = +productsInCart.totalWeight;
       DeliveryCharge = TotalWeight * deliveryCharged;
       totalTaxAmount = +productsInCart.totalTax;
       totalTaxAmount = totalTaxAmount + +tax;
       let gnAlstrdPrdtsTtlAmnt = productsInCart.products.map(x =>{ return +x.totalAmount});
       TotalAmount = gnAlstrdPrdtsTtlAmnt.reduce((a, b) => a + b, 0);
      console.log('typed of TotalWeight ',typeof TotalWeight, TotalWeight);//number
      TotalWeight = TotalWeight + +weight;
      DeliveryCharge = TotalWeight * deliveryCharged;
      TotalAmount = TotalAmount + DeliveryCharge + +totalAmount;

      console.log("old products is ",Oldproducts);
      Oldproducts.push(productData);
      updatedCartItems = [...Oldproducts];

      console.log("updatedcart items ",updatedCartItems);
      console.log("new  products is ",Oldproducts);
      console.log('total weight ',TotalWeight,' Delivery Charge ',DeliveryCharge,' TotalAmount ',TotalAmount);

     CustomerCart.findById(productsInCart._id).then(cartsItems =>{
      cartsItems.products = updatedCartItems;
      cartsItems.totalWeight = TotalWeight;
      cartsItems.deliveryCharge = DeliveryCharge;
      cartsItems.totalTax = totalTaxAmount.toFixed(2);
      cartsItems.totalAmount = TotalAmount.toFixed(2);
      cartsItems.save()
      .then(result =>{
        console.log('your cart result is ',result);
        res.status(201).json({
          message:"added to cart !"
        });
      })
      .catch(err => {
        console.log(err);
        res.status(203).json({
          message:"Non-Authoritative Information",
          errorMessage:err.errorMessage
        })
      });
    })
    }
  })
  .catch(err => {
    console.log(err);
    res.status(203).json({
      message:"Non-Authoritative Information",
      errorMessage:err.errorMessage
    })
  });
}

exports.getCustomerCart = (req,res,next) =>{

  let allProdprice=0;
  if(!req.cust){
    return res.status(401).json({
      message:"You are Unauthorized !"
    })
  }

  CustomerCart.findOne({userID:req.cust._id}).select('-userID')
  .then(productData =>{

    if(!productData){
     return res.status(203).json({
        message:"content not available",
        cartInfo:null,
        errorMessage:"Content is not Available for this user"
      })
    }
    let totalamount = productData.products.map(x =>{ return +x.price});
    allProdprice = totalamount.reduce((a, b) => a + b, 0);
    console.log('your all prod price ',allProdprice);
    console.log('your customer cart product data ',productData);
    res.status(200).json({
      message:'data has been fetch',
      cartInfo:[productData],
      allProdPrice : allProdprice

    })



  })
  .catch(err => {
    console.log(err);
    res.status(203).json({
      message:"Non-Authoritative Information OR content not available",
      cartInfo:null,
      errorMessage:err.errorMessage
    })
  });
}

<<<<<<< HEAD


//trashing item from database method
exports.trashThisCartItem = (req,res,next) =>{


=======
//trashing item from database method
exports.trashThisCartItem = (req,res,next) =>{

>>>>>>> Attaywalebaba/backend-master
  const custCartProdItemID = req.params.prodID;
  let TotalWeight = 0;
  let TotalAmount = 0;
  let TotalTax = 0;
  let DeliveryCharge = 0;
  let deliveryCharged = 2; //₹ defined first place
  let cartItemsProducts =[];
  let updatedCartItemProdcuts=[];
  let trashProductID = null;
  // console.log("delete form db", custCartProdItemID);

  if(!req.cust){
    return res.status(401).json({
      message:"You are Unauthorized !"
    });
  }

  let dataCollect =[];
  // let garbageCollect =[];
  // return CustomerCart.findOne({userID:req.cust._id});
  CustomerCart.findOne({userID:req.cust._id})
  .then(userCartFound => {

    console.log(userCartFound.products);//._id == custCartProdItemID
    let prodLenght = userCartFound.products.length;
    console.log("CHECKING : your product on top and lenght too",userCartFound.products, prodLenght);

    if(prodLenght == 1){

       console.log(" one more time , CHECKING : your product on top and lenght too",userCartFound.products, prodLenght);
      CustomerCart.deleteOne({_id:userCartFound._id,userID:req.cust._id})
      .then(result =>{
        if(result.n > 0){
          userCartFound._id = null;
        }

        console.log('BOSS YOUR DELETED REUSLT',result," your id ",userCartFound._id);
         res.status(200).json({
          message:"your cart is empty now",
          data:result
        });

      })
      .catch(err =>{
        res.status(503).json({
          message:"service unavailabe",
          data:err
        })
      })
    }

    else{
<<<<<<< HEAD

=======
>>>>>>> Attaywalebaba/backend-master
    cartItemsProducts = userCartFound.products;
    TotalWeight = +userCartFound.totalWeight;
    TotalAmount = +userCartFound.totalAmount
    TotalTax = +userCartFound.totalTax;
    DeliveryCharge = +userCartFound.deliveryCharge;

    console.log(`origin : TotalWeight ${TotalWeight} TotalAmount ${TotalAmount} TotalTax ${TotalTax} DeliveryCharge ${DeliveryCharge}`);

    // console.log("your founded product is ",
    cartItemsProducts.map(itesm =>{ itesm._id == custCartProdItemID ? dataCollect = itesm : garbageCollect = itesm });
    console.log('your products ',userCartFound);
    let {weight,totalAmount,tax} = dataCollect;
    trashProductID = dataCollect._id;

    console.log('your founded prodouct id (trashProductID) ',trashProductID);
    console.log('your single products  ',dataCollect);
    console.log("your whole product items ",cartItemsProducts);
    console.log(`your weight ${weight} | totalAmount ${totalAmount} | tax ${tax}`);

    TotalWeight = TotalWeight - +weight;
    DeliveryCharge = TotalWeight * deliveryCharged;
    TotalTax = TotalTax - +tax;
    let countAmount = (weight * deliveryCharged) + +totalAmount;
    console.log("your count amount ",countAmount);

<<<<<<< HEAD

=======
>>>>>>> Attaywalebaba/backend-master
    console.log(`After Calculas : TotalWeight ${TotalWeight} Delivery Charge ${DeliveryCharge} TotalTax ${TotalTax}`)
    console.log("your initial total amount ",TotalAmount);
    TotalAmount = TotalAmount - countAmount;
    console.log('your total amount before all delivery added, delivery  ',TotalAmount.toFixed(2), ' ',DeliveryCharge);
    // TotalAmount = TotalAmount + DeliveryCharge; //this line were add bug to my logic
<<<<<<< HEAD

=======
>>>>>>> Attaywalebaba/backend-master
    let yourValues = cartItemsProducts.map(items => { return items._id == trashProductID});
    console.log("your values array ",yourValues);//code done
    let foundedIndex = 0;
    for(let i = 0; i < yourValues.length; i++){
      console.log('value of i ',i);
      if(yourValues[i] == true){
        foundedIndex = i;
        break;
      }
    }
    console.log('your found item index is ',foundedIndex);

    cartItemsProducts.splice(foundedIndex,1);
    updatedCartItemProdcuts = cartItemsProducts;
    console.log('your origin updated products items, count ', cartItemsProducts, cartItemsProducts.length);
    console.log(`your Origin weight ${TotalWeight} | delivery Charge ${DeliveryCharge} | Origin totalAmount ${TotalAmount.toFixed(2)} | Origin tax ${TotalTax.toFixed(2)}`);
    console.log('your user id',userCartFound._id);
     CustomerCart.findById(userCartFound._id)
     .then(userCartInfo =>{
      console.log('here is main error 1');

      userCartInfo.products = updatedCartItemProdcuts;
      userCartInfo.totalWeight = TotalWeight;
      userCartInfo.deliveryCharge = DeliveryCharge;
      userCartInfo.totalTax = TotalTax.toFixed(2);
      userCartInfo.totalAmount = TotalAmount.toFixed(2);
      userCartInfo.save()
      .then(result =>{
        res.status(200).json({
          message:"products has been changes",
          data:result
        })
      })
      .catch( err =>{
        res.status(503).json({
          message:"service not available, your deletion might had problem",
          data:err
        })
      })
      })
      .catch(err =>{
        console.log("your second ")
        res.status(503).json({
          message:"service unavailabe, your cart's products would have problem",
          data:err
        })
      })
    }
  })
  .catch(err =>{
     console.log("either user not founded or database is not responding properly",err);
    res.status(503).json({
      message:"service unavailabe",
      data:err
    })
  });

}

