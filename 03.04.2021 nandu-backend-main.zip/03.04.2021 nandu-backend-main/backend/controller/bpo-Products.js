const Products = require('../models/product');


exports.addProducts = (req,res,next) =>{

  if(!req.bpouser){
    return res.status(401).json({
      message:"you are not authorized to do so.",
      data: "your login credential not valid"
    });
  }

  /** surcharge:surcharge,
        sgst:sgst,
        cgst:cgst, */
  const productID = req.body.id;
  const productName = req.body.productname;
  const grindingType = req.body.grindingtype;
  const weight = req.body.weight;
  const price = req.body.price;
  const serviceCharge = req.body.servicecharge;
  const surCharge = req.body.surcharge;
  const sGst = req.body.sgst;
  const cGst = req.body.cgst;
  const totalAmount = req.body.totalamount;
  const imageurl = req.body.imageurl;
  const productStatus = req.body.productstatus;
  const detail = req.body.detail;
  // const bpoID = req.bpouser._id;

  const productInfo = new Products({
    productName : productName,
    grindingType : grindingType,
    weight : weight,
    price : price,
    serviceCharge : serviceCharge,
    surCharge : surCharge,
    sGST:sGst,
    cGST:cGst,
    totalAmount : totalAmount,
    imageUrl : imageurl,
    productStatus : productStatus,
    detail : detail,
    bpoID : req.bpouser._id
  });
  productInfo.save().then(rs => {
    res.status(201).json({
      message: 'product data stored successfully',
      data: rs
    })
  }).catch(err => {
    console.log(err);
    res.status(511).json({
      message:"Network Authentication Required, also check below Error",
      errorMessage:err.errorMessage
    })
  });

}

exports.showProducts = (req,res,next) =>{

  Products.find().select('-bpoID -price -serviceCharge')
  .then(productsInfo =>{
    console.log('your bpo products ', productsInfo);
    res.status(200).json({
      message : "your provider is working",
      productData : productsInfo
    })
  }
  ).catch();

}

exports.getProductByID = (req,res,next) =>{

  const productID = req.params.prodId;
  console.log('your single product id is ', productID);
  Products.findById(productID).select('-bpoID -price -serviceCharge')
  .then(prodInfo=>{
    // console.log('your single prod info ',prodInfo);
    res.json({
      message:"Product is available",
      data :[prodInfo]
    });
  })
  .catch();


}
