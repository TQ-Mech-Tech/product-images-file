const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Customer = require('./models/customer');
const BpoLogin = require('./models/bpologin');
const customerProfileRoute = require('./Routes/customerprofile');
const bpoProductsRoute = require('./Routes/bpo-product');
const customerCartRoute = require('./Routes/customerCarts');
var cors = require('cors');

const app = express();

app.use(cors());
app.use(bodyParser.json());

app.use(bodyParser.urlencoded({extended:false}));

app.use((req, res, next) => {
  BpoLogin.findById('6045b57008b6f94afc8d77bb')
  .then(bpouser =>{
    req.bpouser = bpouser;
    console.log(req.bpouser);
    next();
  })
  // Customer.findById('603e1169c1bce94d0850d65b')
  //   .then(cust => {
  //     req.cust = cust;
  //     console.log(req.cust);
  //     next();
  //   })
    .catch(err => console.log(err));
});
// ,{ useNewUrlParser: true }
// mongodb+srv://tqmechtechdev:<password>@cluster0.dmnpw.mongodb.net/myFirstDatabase?retryWrites=true&w=majority
mongoose
  .connect(
    "mongodb+srv://tqmechtechdev:kgSU2EA2mo5RI9FW@cluster0.dmnpw.mongodb.net/myFirstDatabase"
  )
  .then(() => {
    console.log("Connected to database!");
    BpoLogin.findOne().then(bpouser =>{
      if(!bpouser){
        const bpoUser = new BpoLogin({
          email:'tqmechtech@gmail.com',
          password:"crazyaremanywhodaretochangetheword"
        });
        bpoUser.save();
      }
    })
    // Customer.findOne().then(customer =>{
    //   if(!customer){
    //     const customer = new Customer({
    //       username:'sohame',
    //       email:'sohamerajput@gmail.com',
    //       mobile:'7218502858',
    //       password:"crazyareoneswhodaretochangetheword"
    //     });
    //     customer.save();
    //   }
    // });

  })
  .catch(() => {
    console.log("Connection failed!");
  });




app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET,POST,PATCH,PUT,DELETE,OPTIONS"
  );
  next();
});


// app.use("/api/customerProfile/add-cust-profile",)

app.use("/api/customerprofile", customerProfileRoute);//http://localhost:3000/api/customerprofile/add-customer-profile

app.use("/api/bpo-addproductservice",bpoProductsRoute);//http://localhost:3000/api/bpo-addproductservice/add-products
///api/bpo-addproductservice/get-added-product /**for fetcing all product to common window */
//http://localhost:3000/api/bpo-addproductservice/add-grinding-products
// http://localhost:3000/api/bpo-addproductservice/get-grind-products
//http://localhost:3000/api/bpo-addproductservice/get-grind-products-calculate
app.use("/api/customercart",customerCartRoute);
// http://localhost:3000/api/customercart/add-customer-cart
///deleteProdItem/:id

module.exports = app;
