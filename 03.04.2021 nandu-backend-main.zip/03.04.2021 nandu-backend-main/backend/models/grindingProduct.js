const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const grindingProduct = new Schema({

  productName :{
    type: String,
    required:true
  },
  grindingType :{
    type:String,
    required:true
  },
  weight:{
    type:String,
    required:true
  },
  price:{
    type:String,
    required:true
  },
  serviceCharge:{
    type:String,
    required:true
  },
  totalAmount:{
    type:String,
    required:true
  },
  bpoUserID:{
      type:Schema.Types.ObjectId,
      required:true,
      ref:'BpoLogin'
    }

});

module.exports = mongoose.model("GrindingProduct",grindingProduct);
