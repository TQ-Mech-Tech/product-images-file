const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const productService = new Schema({

  productName :{
    type: String,
    required:true
  },
  grindingType :{
    type : String,
    required :true
  },
  weight :{
    type : String,
    required : true
  },
  price :{
    type : String,
    required : true
  },
  serviceCharge : {
    type : String,
    required :true
  },
  surCharge:
  {
    type:String,
    require:true
  },
  sGST:{
    type:String,
     required:true
  },
  cGST:{
   type:String,
   required:true
 },
  totalAmount:{
    type:String,
    required:true
  },
  imageUrl :{
    type :String,
    required:true
  },
  productStatus:{
    type:String,
    required:true
  },
  detail :{
    type :String,
    required:true
  },
  bpoID:{
    type:Schema.Types.ObjectId,
    required:true,
<<<<<<< HEAD
    ref:'CustomerSignUp'
=======
    ref:'BpoLogin'
>>>>>>> Attaywalebaba/backend-master
  }
});

module.exports = mongoose.model("Products",productService);
