const mongoose = require('mongoose');
const uniqueValidator = require("mongoose-unique-validator");
const Schema = mongoose.Schema;

const customerSchema = new Schema({

  username:{
    type:String,
    required:true,
    unique:true
  },
  email:{
    type:String,
    required:true,
    unique:true
  },
  mobile:{
    type:Number,
    required:true,
    unique:true
  },
  password:{
    type:String,
    required:true
  },
  otp:{
    type:String
  }

});

customerSchema.plugin(uniqueValidator);
module.exports = mongoose.model("CustomerSignUp",customerSchema);











///////////////////////////////////////////////////
 // username
          // email
          // mobile
          // password
          // otp
