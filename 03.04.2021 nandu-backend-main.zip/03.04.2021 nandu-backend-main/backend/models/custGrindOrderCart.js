const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const custGrindOrdersCart = new Schema({
  todaysDate :{
    type:String,
    required:true
  },
  GrindProducts:[{
    prodID:{
      type:Schema.Types.ObjectId,
      required:true,
      ref:'GrindingProduct'
    },
    prodName:{
      type:String,
      required:true
    },
    prodType:{
      type:String,
      required:true
    },
    weight:{
      type:String,
      required:true
    },
    price:{
      type:String,
      required:true
    },
    serviceCharge:{
      type:String,
      required:true
    },
    totalAmount:{
      type:String,
      required:true
    }

  }],
  pickUpDate:{
    type:String,
    required:true
  },
  droppingDate:{
    type:String,
    required:true
  },
  totalWeight:{
    type:String,
    required:true
  },
  totalTax:{
    type:String,
    required:true
  },
  deliveryCharges:{
    type:String,
    required:true
  },
  FinalAmount:{
    type:String,
    required:true
  },
  userID:{
    type:Schema.Types.ObjectId,
    required:true,
    ref:'CustomerSignUp'
  }

});
module.exports = mongoose.model("CustGrindOrderCart",custGrindOrdersCart);
//module.exports = mongoose.model("GrindingProduct",grindingProduct);
