const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const customerProfile = new Schema({
firstName:{
  type:String,
  required:true
  },
  middleName:{
    type:String,
    required:true
  },
  lastName:{
    type:String,
    required:true
    },
  address:{
    type:String,
    required:true
    },
  sectorNo:{
    type:String,
    required:true
    },
  plotNo:{
    type:String,
    required:true
    },
  state:{
    type:String,
    required:true
    },
  dist:{
    type:String,
    required:true
    },
  tal:{
    type:String,
    required:true
    },
  city:{
    type:String,
    required:true
    },
  pin:{
    type:String,
    required:true
    },
  mob:{
    type:String,
    required:true
    },
  customerId:{
    type:Schema.Types.ObjectId,
    required:true,
    ref:'CustomerSignUp'
  }
});

module.exports = mongoose.model("CustomerProfile",customerProfile);

/*

 type: Schema.Types.ObjectId,
      required: true,
      ref: 'User'

customer-id
firstname
middlename
lastname
address
sectorNo
plotNo
state
dist
tal
city
pin
mob
*/
