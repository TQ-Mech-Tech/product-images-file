const mongoose = require('mongoose');
const { trimSingleQuotes } = require('tslint/lib/utils');
const Schema = mongoose.Schema;

const customerCart = new Schema({

  products:[{
    _id:{
      type:Schema.Types.ObjectId,
      ref:'Products',
      required:true
    },
    productName:{
      type:String,
      required:true
    },
    grindingType:{
      type:String,
      required:true
    },
    price:{
      type:String,
      required:true
    },
    tax:{
      type:String,
      required:true
    },
    weight:{
      type:String,
      required:true
    },
    totalAmount:{
      type:String,
      required:true
    }
  }],
  totalWeight:{
    type:String,
    required:true
  },
  deliveryCharge:{
    type:String,
    required:true
  },
  totalTax:{
    type:String,
    required:true
  },
  totalAmount:{
    type:String,
    required:true
  },
  userID:{
    type:Schema.Types.ObjectId,
    required:true,
    ref:'CustomerSignUp'
  }

});
module.exports = mongoose.model("CusomerCart",customerCart);
