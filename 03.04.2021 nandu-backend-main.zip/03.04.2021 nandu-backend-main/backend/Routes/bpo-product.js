const express = require('express');
const router = express.Router();

const bpoProducts = require('../controller/bpo-Products',);
const bpoGrindingProd = require('../controller/bpo-grinding-products');
router.post('/add-products',bpoProducts.addProducts);
router.get('/get-added-product',bpoProducts.showProducts);
router.get('/get-single-product/:prodId',bpoProducts.getProductByID);
router.post('/add-grinding-products',bpoGrindingProd.addGrindingProducts);
router.get('/get-grind-products',bpoGrindingProd.getGrindingProducts);
router.post('/get-grind-products-calculate',bpoGrindingProd.calculatCustomerGrindingProducts);

module.exports = router;
