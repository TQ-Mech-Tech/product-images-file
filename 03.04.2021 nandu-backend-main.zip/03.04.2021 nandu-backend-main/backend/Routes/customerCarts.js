const express = require('express');
const router = express.Router();

const customerCart = require('../controller/customerCart');

router.post('/add-customer-cart',customerCart.addCustomerCart);
//http://localhost:3000/api/customercart/get-customer-cart
router.get('/get-customer-cart',customerCart.getCustomerCart);
router.delete('/delete-product-item/:prodID',customerCart.trashThisCartItem);
//deleteProdItem/",prodID
module.exports = router;
