const express = require('express');
const router = express.Router();

const customerProfile = require('../controller/customerProfile');

router.post('/add-customer-profile',customerProfile.addCustomerProfile);
router.get('/add-customer-profile',customerProfile.getCustomerProfile);
router.put('/add-customer-profile/:custprofileid',customerProfile.updateCustomer);




module.exports = router;
